# Vérifications du livrable

Préparation du kit le 22 octobre 2026 pour Aurora `4fc2b45cb`.

- Couverture contrôlée contre les tables du source : **221 fiches, 395 noms/variantes, 24 réglages**. Empreintes de quatre fichiers RLVa enregistrées et vérifiées.
- **8 scripts analysés avec lslint : zéro erreur, zéro avertissement**. Ce résultat ne remplace pas leur compilation dans le simulateur.
- **125 requêtes de lecture**, **66 partitions du catalogue connu**, **988 requêtes de découverte large**. Notecards en lecture seule, identifiants uniques et limite de lignes vérifiés. Les partitions tronquées de découverte doivent encore être affinées pendant les essais.
- Données de la checklist identiques à `tests.json` ; syntaxe JavaScript vérifiée avec `node --check`. Utilitaires Python analysés ; comparateur essayé sur listes synthétiques égales, dédupliquées, avec un manque, et avec un préfixe de chat invalide. Générateur de partitions essayé, y compris son refus d'écraser un fichier.
- Les six blocs de commandes PowerShell du mode d'emploi ont été analysés sans exécution et sans erreur de syntaxe.
- Textures contrôlées : dimensions 512 × 256 et alphas du masque 0/32/33/255 ; damier opaque. Liens locaux Markdown et encodage UTF-8 vérifiés.
- **Aperçu visuel de la checklist non exécuté** : le navigateur intégré a refusé le protocole de fichier local selon sa politique d'URL. Le fichier reste fourni pour ouverture manuelle dans un navigateur.
- **Aucun résultat sur grille** : pas de connexion, compilation serveur LSL, message envoyé, demande de permission, attache, téléversement ni transaction. Les 221 lignes de résultats sont volontairement `NON TESTE`.
- Aucun code du viewer modifié pendant la préparation du kit. Les contrôles complets Rust antérieurs de la révision sont décrits dans le guide ; ils n'ont pas été relancés pour ces fichiers de validation.

`SHA256SUMS.txt` contient les empreintes de tous les autres fichiers de ce dossier. Le ZIP contient le même kit dans un dossier unique.
