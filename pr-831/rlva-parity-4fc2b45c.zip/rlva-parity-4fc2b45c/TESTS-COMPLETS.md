# Tous les tests de parité fonctionnelle RLVa

**221 fiches — aucun résultat de grille prérempli.** Lire [LISEZ-MOI.md](LISEZ-MOI.md) pour construire les objets, paramétrer les variables, préparer l’inventaire et arrêter les restrictions. Une ligne `A|...` se saisit sous la forme `/210001 A|...`. Les instructions narratives doivent être réalisées manuellement.

## Index des familles

- [Préparation (9)](#p01)
- [Mouvement (6)](#m01)
- [Assise (2)](#m07)
- [Téléportation (6)](#t01)
- [Chat (6)](#c01)
- [IM (8)](#i01)
- [Inventaire (13)](#w01)
- [Forces d’inventaire (27)](#wf01)
- [Caméra (4)](#k01)
- [Vision (9)](#v01)
- [Confidentialité (3)](#d01)
- [Actions (5)](#a01)
- [Groupes (1)](#g01)
- [Permissions (3)](#g02)
- [Attaches temporaires (2)](#g05)
- [Reconnexion et reprise (5)](#r01)
- [Environnement (4)](#e00)
- [Propriétés d’environnement (87)](#ep001)
- [Debug (1)](#e99)
- [Exceptions sécurisées (20)](#s01)

<a id="p01"></a>
## P01 — Défaut, activation, persistance et anciennes préférences

**Famille :** Préparation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Sur un profil neuf de test, ouvrir Préférences > Protections avant de se connecter : relever le commutateur RLVa et les options subordonnées.

2. Activer RLVa, fermer/réouvrir les préférences puis redémarrer le viewer : relever la persistance.

3. Envoyer :

   ```text
   /210001 A|@version={R}
   ```

4. Désactiver globalement RLVa.

5. Envoyer :

   ```text
   /210001 A|@fly=n,version={R}
   ```

6. Essayer de voler ; vérifier le chat OwnerSay et l'absence de réponse de protocole.

7. Réactiver RLVa sans renvoyer de commande ; examiner la liste de restrictions.

**Résultat attendu :** Aurora démarre avec RLVa désactivé ; activation persistante. Désactivé : commandes ignorées comme OwnerSay ordinaire, vol libre, pas de réponse. Réactivation : aucune ancienne restriction. La migration des anciens réglages est aussi couverte par le test hors ligne rlva_inventory_preferences_keep_reference_defaults_for_old_and_partial_settings.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `version`, `fly`.

**Réglages couverts :** `rlva_enabled`.

<a id="p02"></a>
## P02 — Deux UUID d’émetteurs et suppression isolée

**Famille :** Préparation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|info
   ```

2. Envoyer :

   ```text
   /210001 B|info
   ```

3. Envoyer :

   ```text
   /210001 A|@fly=n,jump=n
   ```

4. Envoyer :

   ```text
   /210001 B|@fly=n
   ```

5. Envoyer :

   ```text
   /210001 A|@fly=y
   ```

6. Essayer de voler : B doit encore bloquer.

7. Envoyer :

   ```text
   /210001 B|@clear
   ```

8. Voler puis essayer de sauter.

9. Envoyer :

   ```text
   /210001 A|@clear=jump
   ```

10. Envoyer :

   ```text
   /210001 A|@getstatus={R}
   ```

11. Envoyer :

   ```text
   /210001 B|@getstatus={R}
   ```

**Résultat attendu :** UUID A et B distincts. La suppression chez A ne libère pas B. Après suppression B : vol libre, saut encore bloqué par A ; clear filtré enlève seulement jump. Les dernières réponses de statut sont vides.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `fly`, `jump`, `getstatus`, `getstatusall`.

<a id="p03"></a>
## P03 — Analyse syntaxique, doublons et notifications

**Famille :** Préparation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@notify:210103=n
   ```

2. Envoyer :

   ```text
   /210001 A|@FLY=N,fly=n,jump=add,jump=rem
   ```

3. Envoyer :

   ```text
   /210001 A|@getstatus={R}
   ```

4. Envoyer :

   ```text
   /210001 A|@clear:missing
   ```

5. Envoyer :

   ```text
   /210001 A|@getstatus={R}
   ```

6. Envoyer :

   ```text
   /210001 A|@unknown=n,fly:invalid=n,fly_sec=n
   ```

7. Envoyer :

   ```text
   /210001 A|@getstatus={R}
   ```

8. Envoyer :

   ```text
   /210001 A|@CLEAR=fly
   ```

9. Envoyer :

   ```text
   /210001 A|@getstatus={R}
   ```

**Résultat attendu :** Casse normalisée ; doublon idempotent, add/rem équivalents à n/y. clear:missing sans = ne supprime rien ; options/commandes invalides ne créent aucune restriction. notify reçoit les notifications prévues même pour doublons/refus. Le clear filtré ne retire pas notify.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `notify`, `getstatus`, `fly`, `clear`.

<a id="p04"></a>
## P04 — Origine des commandes et enfant de linkset

**Famille :** Préparation. **Préconditions :** A, C en enfant, sonde appartenant au témoin.

1. Depuis le chat de l’avatar principal, saisir @fly=n sans contrôleur.

2. Depuis le compte témoin, utiliser la sonde : /210005 direct @fly=n ; /210005 im @fly=n.

3. Vérifier le vol après chaque tentative.

4. Mettre un contrôleur C dans le prim enfant d’un linkset et A dans sa racine ; configurer des descriptions distinctes avant de réinitialiser.

5. Envoyer :

   ```text
   /210001 C|@jump=n
   ```

6. Envoyer :

   ```text
   /210001 A|@getstatusall={R}
   ```

7. Envoyer :

   ```text
   /210001 A|@clear
   ```

8. Essayer de sauter.

9. Envoyer :

   ```text
   /210001 C|clear
   ```

**Résultat attendu :** Seul OwnerSay d’objet peut imposer une commande. Chat d’avatar, message direct d’objet et IM d’objet ne le peuvent pas. L’enfant apparaît avec son propre UUID ; clear racine ne supprime pas une règle de l’enfant.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getstatusall`, `jump`.

<a id="p05"></a>
## P05 — Versions et balayage des requêtes

**Famille :** Préparation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@version={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@versionnew={R}
   ```

3. Envoyer :

   ```text
   /210001 A|@versionnum={R}
   ```

4. Envoyer :

   ```text
   /210001 A|@versionnum:impl={R}
   ```

5. Envoyer :

   ```text
   /210001 A|@versionnum:invalid={R}
   ```

6. Envoyer :

   ```text
   /210001 A|sweep RLVa-Queries
   ```

7. Comparer le journal de chaque requête avec celui du Legacy Viewer, dans le même état d’inventaire/caméra/groupe.

8. Attendre la fin du balayage avant toute autre requête.

**Résultat attendu :** Chaînes legacy/new distinctes ; Aurora annonce 3040300 et implémentation 2040213. Les numéros d’implémentation peuvent différer avec une autre version du Legacy Viewer : relever sa version exacte. Option numérique inconnue : réponse vide. REPLIED prouve seulement une réception ; comparer les valeurs, longueurs et réponses vides, jamais seulement la présence d’une réponse.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `findfolder`, `findfolders`, `getaddattachnames`, `getaddoutfitnames`, `getattach`, `getattachnames`, `getcam_avdist`, `getcam_avdistmax`, `getcam_avdistmin`, `getcam_fov`, `getcam_fovmax`, `getcam_fovmin`, `getcam_textures`, `getcommand`, `getdebug_aspectratio`, `getdebug_avatarsex`, `getdebug_renderresolutiondivisor`, `getdebug_restrainedloveforbidgivetorlv`, `getdebug_restrainedlovenosetenv`, `getdebug_windlightuseatmosshaders`, `getgroup`, `getheightoffset`, `getinv`, `getinvworn`, `getoutfit`, `getoutfitnames`, `getpath`, `getpathnew`, `getremattachnames`, `getremoutfitnames`, `getsitid`, `getstatus`, `getstatusall`, `version`, `versionnew`, `versionnum`.

<a id="p06"></a>
## P06 — Canaux de réponse invalides, réponse vide et Unicode

**Famille :** Préparation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@version=0,version=-1,version=2147483647
   ```

2. Vérifier qu’aucune réponse de protocole ne revient sur ces canaux.

3. Envoyer :

   ```text
   /210001 A|@getstatus={R}
   ```

4. Vérifier la réception d’une réponse vide après nettoyage des règles A.

5. Avec IM queries activé, porter plusieurs contrôleurs dont les objets ont des noms Unicode ; demander @list depuis le véritable IM du témoin et observer les longs messages découpés.

6. Comparer les réponses au Legacy Viewer ; vérifier qu’aucun caractère UTF-8 n’est tronqué en caractère de remplacement.

**Résultat attendu :** Canaux de réponse invalides refusés ; une réponse vide est distincte d’un timeout. Les réponses de chat sont bornées à un paquet UTF-8 ; les longues listes privées sont découpées sans corruption. La limite exacte de 1023 octets et les champs paquet sont couverts par les tests hors ligne ; les copies de chat seules ne prouvent pas les octets sur le réseau.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `version`, `getstatus`.

<a id="p07"></a>
## P07 — Compatibilité de version par créateur et nom

**Famille :** Préparation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Sans entrée de compatibilité, interroger versionnum et versionnum:impl depuis A.

2. Ajouter dans les préférences creator:UUID_DU_CREATEUR_DE_A ; interroger depuis A puis un objet de créateur différent.

3. Remplacer par name:^RLVa Test A$ et nommer A ainsi ; interroger, puis renommer A pour sortir de l’expression.

4. Tester une expression invalide, une expression à lookaround et la casse ; retirer la liste ensuite.

**Résultat attendu :** Seuls les contrôleurs portés qui correspondent annoncent 2092800 ; le numéro d’implémentation reste inchangé. Un objet rezzé/non correspondant reste au protocole normal. Expressions invalides ignorées ; correspondance complète du nom, insensible à la casse. Comparer après confirmation des métadonnées de nom/créateur.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `versionnum`.

**Réglages couverts :** `compatibility_list`.

<a id="p08"></a>
## P08 — Dictionnaire expérimental et diagnostics

**Famille :** Préparation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@getcommand={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@getcommand:;add={R}
   ```

3. Envoyer :

   ```text
   /210001 A|@getcommand:;force={R}
   ```

4. Envoyer :

   ```text
   /210001 A|@getcommand:;reply={R}
   ```

5. Envoyer :

   ```text
   /210001 A|sweep RLVa-Catalogue
   ```

6. Fusionner les réponses par filtre pour reconstruire le catalogue : la réponse globale peut être tronquée à 1023 octets. Si une réponse par filtre atteint cette limite dans la référence, affiner ce filtre avant de conclure.

7. Envoyer :

   ```text
   /210001 A|sweep RLVa-Decouverte
   ```

8. Ce balayage large inclut aussi les préfixes absents d’Aurora. Affiner toutes les partitions tronquées jusqu’à obtenir des réponses complètes ; utiliser generer_partitions.py pour produire les sous-partitions.

9. Désactiver les commandes expérimentales ; redémarrer le Legacy Viewer si nécessaire, puis refaire les requêtes.

10. Envoyer :

   ```text
   /210001 A|@shownearby=n
   ```

11. Vérifier l’absence de nouvelle restriction expérimentale ; réactiver l’option puis refaire la commande.

12. Activer le journal des commandes ; envoyer deux fois fly=n puis deux fois fly=y, avec puis sans masquage des doublons/non-définis.

13. Désactiver le journal et restaurer les valeurs de départ.

**Résultat attendu :** Catalogue filtré selon le type et les commandes disponibles. Les commandes expérimentales actives doivent rester supprimables. Aurora applique le réglage immédiatement ; pour la comparaison après redémarrage, placer les deux viewers dans le même état. Journal désactivé par défaut ; le filtre masque uniquement les retours doublon/non-défini.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getcommand`, `shownearby`, `fly`.

**Réglages couverts :** `experimental_commands`, `debug_commands`, `debug_hide_unset_duplicate`.

<a id="p09"></a>
## P09 — Console, émetteur indépendant et fermeture

**Famille :** Préparation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Ouvrir les outils RLVa et leur console dans Aurora.

2. Dans la console, saisir @fly=n,version=0,getstatusall=0.

3. Envoyer :

   ```text
   /210001 A|@jump=n
   ```

4. Examiner les onglets restrictions, verrous et modificateurs ; filtrer/copier une entrée.

5. Fermer les outils ; tester vol et saut.

6. Réouvrir et désactiver globalement RLVa.

**Résultat attendu :** Réponses canal zéro locales à la console, jamais émises sur le réseau. Fermer la console libère son vol mais conserve jump d’A. Les outils affichent les valeurs/UUID effectivement actifs. La présentation des fenêtres n’est pas un critère de parité comportementale.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `fly`, `jump`, `getstatusall`, `version`.

<a id="m01"></a>
## M01 — fly

**Famille :** Mouvement. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@fly=n
   ```

2. Essayer de voler puis arrêter de voler avec les contrôles natifs.

3. Envoyer :

   ```text
   /210001 A|@fly=y
   ```

4. Refaire exactement la même action.

**Résultat attendu :** La restriction empêche l’action visée ; sa suppression rend le contrôle au réglage natif. Ne pas confondre une interdiction de voler imposée par la parcelle avec fly.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `fly`.

<a id="m02"></a>
## M02 — jump

**Famille :** Mouvement. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@jump=n
   ```

2. Essayer de sauter au sol avec les contrôles natifs.

3. Envoyer :

   ```text
   /210001 A|@jump=y
   ```

4. Refaire exactement la même action.

**Résultat attendu :** La restriction empêche l’action visée ; sa suppression rend le contrôle au réglage natif. Ne pas confondre une interdiction de voler imposée par la parcelle avec fly.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `jump`.

<a id="m03"></a>
## M03 — alwaysrun

**Famille :** Mouvement. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@alwaysrun=n
   ```

2. Essayer de activer la course permanente avec les contrôles natifs.

3. Envoyer :

   ```text
   /210001 A|@alwaysrun=y
   ```

4. Refaire exactement la même action.

**Résultat attendu :** La restriction empêche l’action visée ; sa suppression rend le contrôle au réglage natif. Ne pas confondre une interdiction de voler imposée par la parcelle avec fly.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `alwaysrun`.

<a id="m04"></a>
## M04 — temprun

**Famille :** Mouvement. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@temprun=n
   ```

2. Essayer de courir temporairement avec le raccourci normal avec les contrôles natifs.

3. Envoyer :

   ```text
   /210001 A|@temprun=y
   ```

4. Refaire exactement la même action.

**Résultat attendu :** La restriction empêche l’action visée ; sa suppression rend le contrôle au réglage natif. Ne pas confondre une interdiction de voler imposée par la parcelle avec fly.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `temprun`.

<a id="m05"></a>
## M05 — Vol et rotation forcés, hauteur

**Famille :** Mouvement. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@fly:true=force
   ```

2. Envoyer :

   ```text
   /210001 A|@fly:false=force
   ```

3. Envoyer :

   ```text
   /210001 A|@setrot:1.570796=force
   ```

4. Envoyer :

   ```text
   /210001 B|@fly=n
   ```

5. Envoyer :

   ```text
   /210001 A|@fly:true=force
   ```

6. Envoyer :

   ```text
   /210001 B|clear
   ```

7. Envoyer :

   ```text
   /210001 A|@getheightoffset={R}
   ```

8. Envoyer :

   ```text
   /210001 A|@adjustheight:5=force
   ```

9. Envoyer :

   ```text
   /210001 A|@getheightoffset={R}
   ```

10. Envoyer :

   ```text
   /210001 A|@adjustheight:1.0;1.0;0.0=force
   ```

11. Interroger de nouveau la hauteur puis restaurer manuellement la hauteur initiale.

**Résultat attendu :** Vol forcé respecte les verrous des autres émetteurs. Rotation en radians convertie comme la référence. La forme simple adjustheight est en centimètres ; le réglage automatique de hauteur se désactive. getheightoffset reflète la valeur bornée. Restaurer l’état de vol et la hauteur explicitement : un clear ne promet pas d’annuler chaque force ponctuelle.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `fly`, `setrot`, `adjustheight`, `getheightoffset`.

<a id="m06"></a>
## M06 — Inactivité allowidle

**Famille :** Mouvement. **Préconditions :** Session réservée à ce test long, aucun auto-logout.

1. Envoyer :

   ```text
   /210001 A|lease 0
   ```

2. Régler l’inactivité normale sur une durée courte, par exemple 1 minute, et désactiver toute fermeture automatique de session.

3. Envoyer :

   ```text
   /210001 A|@allowidle=n
   ```

4. Ne fournir aucune entrée pendant plus d’une minute, puis jusqu’au seuil de 30 minutes.

5. Noter l’état Away aux deux seuils.

6. Envoyer :

   ```text
   /210001 A|clear
   ```

7. Restaurer les préférences d’inactivité et A|lease 180.

**Résultat attendu :** Le seuil spécifique de 30 minutes remplace le seuil normal tant que allowidle est actif. Il faut une vraie attente sans mouvement/saisie ; un simple clic après une minute invalide le test de 30 minutes.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `allowidle`.

<a id="m07"></a>
## M07 — Interdictions, racine de siège et forces

**Famille :** Assise. **Préconditions :** Compte principal, contrôleurs A et B.

1. S’asseoir normalement sur la cible ; interroger A|@getsitid={R} puis tenter de se lever sous A|@unsit=n.

2. Envoyer :

   ```text
   /210001 A|@unsit=force
   ```

3. Comparer le cas où le même émetteur impose unsit, puis celui où B impose unsit=n.

4. Envoyer :

   ```text
   /210001 A|clear
   ```

5. Envoyer :

   ```text
   /210001 B|clear
   ```

6. Envoyer :

   ```text
   /210001 A|@sit=n
   ```

7. Essayer de s’asseoir sur l’objet, au sol, puis A|@sit:{SEAT}=force.

8. Envoyer :

   ```text
   /210001 A|clear
   ```

9. Envoyer :

   ```text
   /210001 A|@sit:{SEAT}=force
   ```

10. Envoyer :

   ```text
   /210001 A|@getsitid={R}
   ```

11. Envoyer :

   ```text
   /210001 A|@sitground=force
   ```

12. Vérifier l’ordre : quitter le siège confirmé puis s’asseoir au sol.

13. Envoyer :

   ```text
   /210001 A|@sit:00000000-0000-0000-0000-000000000000=force
   ```

**Résultat attendu :** Unsit interdit le lever courant ; force unsit peut exempter son propre émetteur mais pas B. Sit objet forcé conserve les interdictions sit/unsit applicables. getsitid renvoie la racine du siège ; UUID nul désigne le sol. Pas d’assise au sol anticipée avant confirmation du lever.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sit`, `sitground`, `unsit`, `getsitid`.

<a id="m08"></a>
## M08 — Distances et standtp

**Famille :** Assise. **Préconditions :** Compte principal, contrôleurs A et B.

1. Choisir un siège à plus de 3 m.

2. Envoyer :

   ```text
   /210001 A|@sittp:2=n,fartouch:2=n
   ```

3. Essayer l’assise manuelle au-delà de la limite puis A|@sit:{SEAT}=force.

4. Envoyer :

   ```text
   /210001 A|clear
   ```

5. Revenir au point de départ, puis A|@standtp=n,sit:{SEAT}=force.

6. Après confirmation de l’assise, se lever normalement ; comparer la position d’arrivée avec le point de départ.

7. Refaire avec un siège inaccessible/une assise échouée, puis avec une nouvelle restriction posée par B avant le lever.

**Résultat attendu :** Distance d’assise manuelle strictement inférieure au rayon. L’assise forcée peut ignorer la distance, pas les verrous sit/unsit. Standtp retourne après une assise puis un lever réellement confirmés ; une tentative échouée ne provoque aucun retour. Noter les cas où une autre restriction modifie la séquence.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sittp`, `fartouch`, `standtp`, `sit`.

<a id="t01"></a>
## T01 — Toutes les entrées utilisateur et préflight

**Famille :** Téléportation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@tplm=n,tploc=n,tplocal=n,sittp=n
   ```

2. Essayer Home via menu et raccourci de chat ; landmark via inventaire/favoris ; carte ; historique avant/arrière ; lieu/profil/pick ; lien secondlife:///app/teleport/... ; double clic dans le monde si configuré pour téléporter.

3. Pour chaque route, relever mouvement, progression et historique.

4. Envoyer :

   ```text
   /210001 A|clear
   ```

5. Répéter chaque route vers une destination de test autorisée.

**Résultat attendu :** Les routes interdites ne démarrent pas une progression pendante et ne déplacent pas le curseur d’historique. Le même trajet réussit après suppression, sous réserve des permissions du simulateur. tplm couvre Home/landmarks ; tploc couvre les téléports distants ; tplocal/sittp les locaux.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `tplm`, `tploc`, `tplocal`, `sittp`.

<a id="t02"></a>
## T02 — Frontières des rayons locaux et origine de région

**Famille :** Téléportation. **Préconditions :** Destinations autorisées mesurables, région voisine/grande région pour les variantes.

1. À partir d’un point noté, imposer A|@sittp:10=n,tplocal:10=n.

2. Tester une destination à 9,9 m, exactement 10 m et 10,1 m, puis une destination proche horizontalement mais beaucoup plus haute.

3. Recommencer au bord d’une région vers sa voisine, si le terrain le permet, et dans une grande région si disponible.

4. Après chaque essai, relever la position réelle et revenir au point initial sans laisser la force déplacer la base des calculs.

**Résultat attendu :** Sittp utilise XYZ et tplocal XY ; limites exclusives. Un changement de handle de région ne transforme pas un déplacement horizontal proche en téléport distant. La classe local/distant utilise le rayon XY de 256 m, pas seulement le nom de région. Grande région : tester sans supposer qu’elle existe.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sittp`, `tplocal`, `tpto`.

<a id="t03"></a>
## T03 — tpto global/nommé, décimales, heading et forces

**Famille :** Téléportation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|set DESTINATION=X_GLOBAL/Y_GLOBAL/Z_GLOBAL
   ```

2. Envoyer :

   ```text
   /210001 A|@tpto:{DESTINATION};1.570796=force
   ```

3. Relever position et orientation, puis refaire sans heading.

4. Envoyer :

   ```text
   /210001 A|@tpto:{REGION}/{LOCAL};0=force
   ```

5. Tester des offsets nommés négatifs et >256, des coordonnées globales fractionnaires, puis un heading invalide/NaN.

6. Envoyer :

   ```text
   /210001 A|@tploc=n
   ```

7. Envoyer :

   ```text
   /210001 A|@tpto:{DESTINATION}=force
   ```

8. Envoyer :

   ```text
   /210001 B|@tploc=n
   ```

9. Envoyer :

   ```text
   /210001 A|@tpto:{DESTINATION}=force
   ```

**Résultat attendu :** Position fractionnaire conservée ; heading explicite en radians, absent conforme à la référence. Offsets nommés normalisés via l’espace global. Formes invalides sans déplacement. La force peut ignorer le tploc de son émetteur mais pas celui de B. Utiliser uniquement des positions atteignables de test.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `tpto`, `tploc`.

<a id="t04"></a>
## T04 — Réponses différées, maturité et annulation

**Famille :** Téléportation. **Préconditions :** Région non cachée et destination de maturité différente accessible au compte.

1. Lancer un téléport par nom vers une région non présente en cache ; pendant la résolution, imposer la restriction applicable depuis B.

2. Relever le refus tardif, la progression et l’historique.

3. Lancer un téléport qui demande une élévation de maturité ; avant confirmation, poser le verrou applicable ; accepter ensuite la préférence.

4. Lancer une force différée depuis A, désactiver globalement RLVa avant le retour, puis attendre la réponse.

5. Lancer deux demandes nommées successives et vérifier qu’une ancienne réponse ne déclenche pas le premier déplacement.

**Résultat attendu :** Les callbacks re-vérifient les règles et conservent l’émetteur ; refus tardif termine proprement progression/historique. Une force annulée par désactivation ou remplacée par une demande plus récente ne part pas ensuite. La course nécessite des callbacks réellement différés ; si la résolution est instantanée, résultat NON TESTÉ, pas PASS.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `tpto`, `tploc`, `tplm`.

<a id="t05"></a>
## T05 — Offres/demandes, exceptions et texte masqué

**Famille :** Téléportation. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@tplure=n,tprequest=n
   ```

2. Le témoin envoie une véritable offre de TP puis une véritable demande de TP depuis son viewer ; noter ses réponses automatiques.

3. Envoyer :

   ```text
   /210001 A|@tplure:{PEER}=n,tprequest:{PEER}=n
   ```

4. Refaire les deux et refuser manuellement les cartes.

5. Envoyer :

   ```text
   /210001 A|clear
   ```

6. Envoyer :

   ```text
   /210001 A|@recvim=n
   ```

7. Envoyer offre et demande avec un texte reconnaissable.

8. Envoyer :

   ```text
   /210001 A|clear
   ```

9. Envoyer :

   ```text
   /210001 A|@showloc=n
   ```

10. Refaire offre et demande ; comparer les textes et étiquettes de lieu.

**Résultat attendu :** Offre/demande bloquée : réponse busy RLVa, aucune carte acceptante ni faux refus utilisateur. Exceptions autorisent. Texte masqué sous recvim et selon showloc ; les restrictions de maturité restent actives. Pas de spoof de lure par IM d’objet.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `tplure`, `tprequest`, `recvim`, `showloc`.

<a id="t06"></a>
## T06 — Acceptation automatique, statut et assise

**Famille :** Téléportation. **Préconditions :** Deux viewers de comptes consentants ; éventuellement deuxième témoin.

1. Activer le statut « refuser les TP » et DnD.

2. Envoyer :

   ```text
   /210001 A|@accepttp:{PEER}=n,accepttprequest:{PEER}=n
   ```

3. Le témoin envoie offre/demande réelles ; vérifier acceptation et réponse DnD.

4. Envoyer :

   ```text
   /210001 B|@tplure=n,tprequest=n
   ```

5. Refaire ; vérifier qu’aucune acceptation ne contourne B.

6. Envoyer :

   ```text
   /210001 B|clear
   ```

7. S’asseoir, imposer A|@unsit=n et refaire l’offre de TP.

8. Envoyer :

   ```text
   /210001 A|clear
   ```

9. Tester accepttp=n et accepttprequest=n sans UUID avec un deuxième témoin, puis restaurer les statuts.

**Résultat attendu :** L’acceptation automatique prévaut sur le refus/statut utilisateur, tout en conservant les locks, les contrôles de maturité et la réponse DnD. Une offre nécessitant de se lever reste refusée sous unsit ; une demande de TP ne se confond pas avec un déplacement du destinataire.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `accepttp`, `accepttprequest`, `tplure`, `tprequest`, `unsit`.

<a id="c01"></a>
## C01 — sendchat, OOC et emote

**Famille :** Chat. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@sendchat=n
   ```

2. Envoyer une phrase, (( une parenthèse OOC )), un emote /me court, un emote contenant une phrase entre guillemets et un long emote.

3. Refaire avec A|@emote=n.

4. Désactiver puis réactiver l’option OOC et refaire les formes précédentes.

5. Comparer ce que le témoin reçoit, le chat local et les bulles.

**Résultat attendu :** Filtrage et troncature identiques à la référence, sans fuite du texte filtré ; OOC n’est conservé que si son option l’autorise. emote modifie la limite de longueur des emotes filtrés. Conserver les textes de test exacts dans les deux sessions.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sendchat`, `emote`.

**Réglages couverts :** `allow_ooc`.

<a id="c02"></a>
## C02 — Whisper/Normal/Shout et combinaisons

**Famille :** Chat. **Préconditions :** Compte principal, contrôleurs A et B.

1. Pour chatwhisper, chatnormal et chatshout : imposer n, envoyer avec chacun des trois modes, noter le type reçu côté témoin puis retirer y.

2. Répéter les paires de restrictions puis les trois ensemble.

3. Relever la conversion de mode plutôt que supposer qu’une interdiction supprime tout message.

**Résultat attendu :** Les types sont rabattus comme dans le Legacy Viewer ; aucune combinaison ne force l’émission par un mode lui-même interdit.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `chatwhisper`, `chatnormal`, `chatshout`.

<a id="c03"></a>
## C03 — Réception, exceptions, ellipses et origines

**Famille :** Chat. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@recvchat=n,recvemote=n
   ```

2. Le témoin avatar et sa sonde rezzée envoient phrase et /me ; relever chat, bulles, historique et notifications.

3. La sonde utilise direct vers le principal ; un objet porté possédé par le principal parle aussi.

4. Envoyer :

   ```text
   /210001 A|@recvchat:{PEER}=n,recvemote:{PEER}=n
   ```

5. Refaire les messages d’avatar ; puis ajouter recvchatfrom:PEER et recvemotefrom:PEER.

6. Répéter avec l’option ellipses activée puis désactivée.

**Résultat attendu :** Messages filtrés remplacés par ellipses ou supprimés avant historique/bulles selon l’option. Exceptions générales et interdictions spécifiques se combinent correctement. Chat direct d’objet, OwnerSay et attaches possédées portées suivent leurs exemptions ; un objet rezzé possédé n’est pas automatiquement une attache exemptée.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvchat`, `recvemote`, `recvchatfrom`, `recvemotefrom`.

**Réglages couverts :** `show_ellipsis`.

<a id="c04"></a>
## C04 — Redirection et découpage UTF-8

**Famille :** Chat. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@redirchat:210101=n,redirchat:210102=n,rediremote:210102=n
   ```

2. Envoyer phrase, OOC, /me et un texte Unicode long ; compter messages et destinations dans le journal du contrôleur.

3. Répéter l’ajout du même canal depuis B pour contrôler la déduplication.

4. Envoyer :

   ```text
   /210001 A|@sendchannel=n
   ```

5. Envoyer une phrase : tous les canaux étant bloqués, vérifier qu’elle ne revient pas en chat public.

6. Utiliser le toucher du contrôleur pour libérer le verrou canal si nécessaire.

7. Répéter avec le découpage de redirection activé puis désactivé.

**Résultat attendu :** Canaux dédupliqués, texte jamais réémis publiquement faute de destination. Mode normal : réponse unique bornée ; mode découpage : frontières de mots/UTF-8. OOC et emotes suivent leur branche native.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `redirchat`, `rediremote`, `sendchannel`.

**Réglages couverts :** `split_redirect_chat`.

<a id="c05"></a>
## C05 — sendchannel et sendchannel_except

**Famille :** Chat. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@sendchannel=n,sendchannel:210101=n
   ```

2. Envoyer manuellement /210101 probe et /210102 probe ; observer les canaux côté script.

3. Effacer par toucher ou attendre l’expiration affichée : /210001 est lui aussi bloqué sans exception.

4. Envoyer :

   ```text
   /210001 A|@sendchannel_except:210101=n
   ```

5. Envoyer /210101 probe : une entrée seule ne doit pas activer sa restriction générale.

6. Envoyer :

   ```text
   /210001 A|@sendchannel_except=n
   ```

7. Refaire /210101 et /210102.

8. Refaire avec les formes _sec et permissive=n, en répartissant exceptions/règles entre A et B.

9. Tester sendchannel:-5=n, sendchannel:0=n et leurs variantes except : aucune règle valide ne doit être ajoutée.

**Résultat attendu :** Seuls les canaux positifs sont des options valides. sendchannel constitue une liste d’autorisation ; sendchannel_except a besoin de sa règle générale et inverse la liste. Les accords _sec/permissive suivent les émetteurs concernés. Le canal de contrôle n’est jamais exempté automatiquement par le kit.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sendchannel`, `sendchannel_except`, `permissive`.

<a id="c06"></a>
## C06 — Saisie redirigée et gestes

**Famille :** Chat. **Préconditions :** Témoin et geste de test connu.

1. Envoyer :

   ```text
   /210001 A|@redirchat:210101=n,sendgesture=n
   ```

2. Taper sans envoyer : le témoin observe indicateur de saisie, animation et état visible.

3. Activer « afficher la saisie redirigée » ; refaire puis désactiver l’option pendant la frappe.

4. Déclencher un geste de test par raccourci et inventaire, puis enlever sendgesture et recommencer.

**Résultat attendu :** Par défaut les trois chemins de saisie sont masqués ; l’option les réactive ensemble et une nouvelle restriction arrête la saisie active. Le geste est empêché sous sendgesture puis disponible après suppression.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `redirchat`, `sendgesture`.

**Réglages couverts :** `show_redirect_typing`.

<a id="i01"></a>
## I01 — Création privée, groupe, conférence et appel

**Famille :** IM. **Préconditions :** Deux témoins ou comptes, groupe partagé, sessions fermées au début.

1. Fermer toute conversation avec PEER et PEER2 ainsi que le groupe choisi.

2. Envoyer :

   ```text
   /210001 A|@startim=n
   ```

3. Essayer IM depuis Contacts, Personnes, menu d’avatar, profil, recherche, lien d’application et notification ancienne ; essayer le chat de groupe et un appel privé/groupe.

4. Vérifier qu’aucune session vide n’a été créée par ces tentatives.

5. Envoyer :

   ```text
   /210001 A|@startim:{PEER}=n
   ```

6. Ouvrir une conversation avec PEER, puis supprimer l’exception.

7. Réutiliser cette conversation existante ; tenter une conférence avec PEER et PEER2, puis un appel multiple.

8. Envoyer :

   ```text
   /210001 A|@startim:{PEER2}=n,startim:{GROUP}=n
   ```

9. Refaire conférence et groupe ; pendant un appel existant, tenter une conversion avec un participant encore interdit.

**Résultat attendu :** Les nouvelles sessions sont bloquées avant leur création. Une session réellement ouverte reste utilisable ; une tentative refusée ne fabrique pas cette exemption. Tous les participants nouveaux d’une conférence sont vérifiés, le groupe est identifié par son UUID ; refus de création/conversion n’abandonne pas l’appel courant.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `startim`, `startimto`.

<a id="i02"></a>
## I02 — Envoi privé et remplacement local/réseau

**Famille :** IM. **Préconditions :** Compte principal, contrôleurs A et B.

1. Ouvrir d’abord l’IM du témoin.

2. Envoyer :

   ```text
   /210001 A|@sendim=n
   ```

3. Envoyer une phrase reconnaissable avec caractères accentués ; noter le texte affiché et celui réellement reçu par le témoin.

4. Envoyer :

   ```text
   /210001 A|@sendim:{PEER}=n
   ```

5. Refaire ; ajouter A|@sendimto:{PEER}=n et refaire.

6. Taper sans envoyer : contrôler les notifications de saisie.

7. Envoyer :

   ```text
   /210001 A|clear
   ```

8. Renvoyer une phrase différente.

**Résultat attendu :** Sous sendim : texte de remplacement dans l’historique local et sur le réseau, jamais le contenu original. Exception générale autorise ; sendimto réinterdit. Les indicateurs de saisie ne sont pas traités comme du contenu sendim. Suppression libère les messages suivants.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sendim`, `sendimto`.

<a id="i03"></a>
## I03 — Réception en ligne, hors ligne, personnel et réponses automatiques

**Famille :** IM. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@recvim=n
   ```

2. Activer une réponse automatique personnelle identifiable ; le témoin envoie un véritable IM en ligne.

3. Noter le remplacement local et la réponse busy reçue par le témoin ; ne pas confondre busy et IM normal.

4. Envoyer :

   ```text
   /210001 A|@recvim:{PEER}=n
   ```

5. Refaire puis imposer recvimfrom:PEER et refaire.

6. Pour le cas hors ligne : conserver un profil boot recvim=n et lease 0, quitter le viewer, laisser le témoin envoyer un IM hors ligne puis se reconnecter ; noter si le verrou était déjà actif lors de la livraison.

7. Ne pas solliciter un Linden pour ce test : si aucun message réel approprié n’est disponible, inscrire BLOQUÉ pour cette sous-variante, couverte hors ligne par les tests internes.

8. Arrêter boot, effacer les règles, restaurer la réponse automatique et lease 180.

**Résultat attendu :** En ligne : remplacement et busy au bon fil de conversation, sans divulguer la réponse automatique personnelle. Hors ligne : texte conservé ; un vrai IM du personnel conserve aussi son texte et ne déclenche pas la réponse personnelle. Les messages d’objet et un objet nommé Linden ne constituent pas un IM du personnel.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvim`, `recvimfrom`.

<a id="i04"></a>
## I04 — Groupes et conférences : réception et ensemble des destinataires

**Famille :** IM. **Préconditions :** Deux témoins et groupe partagé.

1. Envoyer :

   ```text
   /210001 A|@recvim=n,sendim=n
   ```

2. Depuis un groupe fermé, faire envoyer une invitation de chat par le témoin ; refaire avec une exception recvim pour GROUP, puis seulement pour PEER.

3. Créer une conférence de témoins et observer son message initial bloqué ; une fois ouverte, faire envoyer des messages ordinaires.

4. Autoriser sendim pour PEER seulement ; tenter un message à une conférence qui contient encore PEER2 interdit.

5. Autoriser aussi PEER2 ; refaire. Retirer un participant via le mécanisme natif et refaire après confirmation de la liste.

6. Comparer séparément invitation initiale et trafic d’une session déjà ouverte.

**Résultat attendu :** Réception initiale de groupe vérifie GROUP, pas simplement l’expéditeur ; conférence initiale censure l’expéditeur interdit. Le trafic multi-agent existant suit sa branche native distincte. Envoi de groupe vérifie GROUP ; envoi de conférence vérifie tous les autres participants connus et remplace le texte si l’un reste interdit.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvim`, `sendim`.

<a id="i05"></a>
## I05 — Intervalles de distance et exceptions spécifiques

**Famille :** IM. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@recvim:5;20=n,sendim:5;20=n,startim:5;20=n
   ```

2. Placer PEER à moins de 5 m, à 5 m, entre les limites, à 20 m, au-delà, puis dans une autre région ; à chaque position tester les trois actions avec une nouvelle session si nécessaire.

3. Envoyer :

   ```text
   /210001 B|@sendim:7;15=n
   ```

4. Refaire l’envoi à 6 m, 10 m et 16 m.

5. Envoyer :

   ```text
   /210001 A|@sendimto:{PEER}=n
   ```

6. Refaire dans l’intervalle autorisé.

7. Envoyer :

   ```text
   /210001 A|clear
   ```

8. Envoyer :

   ```text
   /210001 B|clear
   ```

9. Envoyer :

   ```text
   /210001 A|@sendim:20=n
   ```

10. Refaire avec PEER hors région.

**Résultat attendu :** Les intervalles généraux autorisent la zone inclusive prévue ; plusieurs émetteurs intersectent les bornes. Les blocages spécifiques restent prioritaires. La forme minimale sans maximum admet le cas hors région ; une borne maximale finie ne le fait pas. Mesurer depuis la position réelle de l’avatar, pas celle du contrôleur.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvim`, `sendim`, `startim`, `sendimto`.

<a id="i06"></a>
## I06 — Requêtes privées, consentement et confidentialité

**Famille :** IM. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@fly=n,sendim=n,recvim=n,startim=n
   ```

2. Depuis le vrai IM du témoin, envoyer exactement @version, @list et @except, en minuscules et en ligne.

3. Pour la liste : refuser une fois, autoriser une fois puis autoriser en mémorisant ; vérifier qu’une autorisation unique n’est pas mémorisée.

4. Désactiver les requêtes IM puis refaire ; envoyer @VERSION et @fly=n pour vérifier qu’ils ne deviennent jamais commandes d’objet.

5. Répéter avec expéditeur bloqué, filtre amis uniquement et restrictions actives.

6. Remettre les préférences initiales, effacer la mémorisation et supprimer les règles.

**Résultat attendu :** Version répond si les requêtes sont autorisées ; listes et exceptions demandent consentement par défaut. Réponses de protocole peuvent sortir malgré sendim mais aucun IM ne devient émetteur de restriction. Blocages/amis/spam restent appliqués. Désactivation annule aussi les questions/requêtes pendantes.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `version`, `sendim`, `recvim`, `startim`.

**Réglages couverts :** `im_queries`, `im_queries_auto_share`.

<a id="i07"></a>
## I07 — stopim ferme aussi l’appel

**Famille :** IM. **Préconditions :** Compte principal, contrôleurs A et B.

1. Ouvrir une conversation et un appel avec PEER.

2. Envoyer :

   ```text
   /210001 A|@startim=n
   ```

3. PEER envoie @stopim en IM réel.

4. Vérifier fermeture de conversation et fin de l’appel ; tenter de rouvrir.

5. Désactiver les requêtes IM et refaire sur une session ouverte avant la restriction.

6. Tester aussi sans restriction startim.

**Résultat attendu :** stopim ferme une conversation startim-restreinte et son appel même si les requêtes facultatives sont désactivées. Sans restriction, réponse native appropriée plutôt qu’une fermeture arbitraire.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `startim`.

**Réglages couverts :** `im_queries`.

<a id="i08"></a>
## I08 — Partage d’inventaire : share et son exception

**Famille :** IM. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@share=n
   ```

2. Essayer de donner un objet de test au témoin via inventaire, glisser-déposer sur avatar et profil.

3. Envoyer :

   ```text
   /210001 A|@share:{PEER}=n
   ```

4. Refaire le don ; refuser le cadeau côté témoin pour ne pas dupliquer l’inventaire.

5. Répartir share_sec et son exception entre A/B puis refaire.

**Résultat attendu :** Don refusé sous share, autorisé pour une exception suffisante ; le contrôle atteint le chemin natif d’envoi. Un simple affichage grisé sans tentative par une autre entrée ne suffit pas à valider.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `share`.

<a id="w01"></a>
## W01 — Arborescence, recherche et état porté

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Créer exactement l’arborescence FIXTURES décrite dans le guide, sans remplacer la tenue habituelle.

2. Envoyer :

   ```text
   /210001 A|@getinv={R}
   ```

3. Envoyer :

   ```text
   /210001 A|@getinv:RLVa Validation={R}
   ```

4. Envoyer :

   ```text
   /210001 A|@getinvworn:RLVa Validation={R}
   ```

5. Envoyer :

   ```text
   /210001 A|@findfolder:deep&&match={R}
   ```

6. Envoyer :

   ```text
   /210001 A|@findfolders:deep&&match={R}
   ```

7. Porter seulement un accessoire et la chemise de test ; refaire les requêtes, puis ajouter/enlever un geste de test.

8. Recommencer avant que les descendants soient chargés en cache, puis après confirmation du chargement.

**Résultat attendu :** getinv masque les noms cachés/repliés selon les règles natives ; findfolder choisit le résultat de parcours le plus profond, findfolders liste les résultats. getinvworn distingue rien/partiel/tout et descendants ; un dossier non chargé ne doit pas être traité comme vide.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getinv`, `getinvworn`, `findfolder`, `findfolders`.

<a id="w02"></a>
## W02 — Requêtes de points, couches et chemins

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@getattach={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@getattachnames={R}
   ```

3. Envoyer :

   ```text
   /210001 A|@getaddattachnames={R}
   ```

4. Envoyer :

   ```text
   /210001 A|@getremattachnames={R}
   ```

5. Envoyer :

   ```text
   /210001 A|@getoutfit={R}
   ```

6. Envoyer :

   ```text
   /210001 A|@getoutfitnames={R}
   ```

7. Envoyer :

   ```text
   /210001 A|@getaddoutfitnames={R}
   ```

8. Envoyer :

   ```text
   /210001 A|@getremoutfitnames={R}
   ```

9. Envoyer :

   ```text
   /210001 A|@getpath:{SELF}={R}
   ```

10. Envoyer :

   ```text
   /210001 A|@getpathnew:{SELF}={R}
   ```

11. Placer A comme accessoire dans la racine de test partagée ; refaire les deux chemins avec plusieurs liens COF, un nom contenant / et un dossier replié parent.

12. Refaire les noms avec les groupes arms/head/legs/torso/hud et les suffixes de points exacts.

**Résultat attendu :** Ordre binaire historique de getoutfit, casse des points et distinction ajout/retrait conformes. getpath renvoie un chemin original ; getpathnew conserve ordre/duplications COF et ne rapporte pas d’original externe. Le groupe HUD présente une divergence connue de l’ancienne référence : voir ARBITRAGES, consigner DIFF plutôt que masquer le cas.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getattach`, `getattachnames`, `getaddattachnames`, `getremattachnames`, `getoutfit`, `getoutfitnames`, `getaddoutfitnames`, `getremoutfitnames`, `getpath`, `getpathnew`.

<a id="w03"></a>
## W03 — Ajout/retrait par point et couche, corps et tenue courante

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@addattach:chest=n,remattach:skull=n,addoutfit:shirt=n,remoutfit:pants=n
   ```

2. Essayer ajout/remplacement/retrait via inventaire, apparence, tenue sauvegardée, menu d’accessoire et raccourci utilisé habituellement.

3. Recommencer avec les formes générales sans option.

4. Tester les couches de corps séparément avec une copie de tenue de test ; ne pas laisser un retrait de corps produire une tenue invalide.

5. Refaire avec A et B, suppression d’un seul émetteur puis nettoyage complet.

**Résultat attendu :** Aucun chemin COF/rez/detach ne contourne les locks applicables. Les couches de corps restent gérées comme dans la référence ; opérations sur la tenue attendent les métadonnées/confirmations nécessaires.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addattach`, `remattach`, `addoutfit`, `remoutfit`.

<a id="w04"></a>
## W04 — Detach par objet, point et enfant

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Porter A sur poitrine et C en enfant ; A|@detach=n.

2. Tenter le retrait manuel de A, puis C|@detachme=force.

3. Relever l’émetteur/root et les notifications ; nettoyer A avant le cas suivant.

4. Envoyer :

   ```text
   /210001 A|@detach:chest=n
   ```

5. Porter un second objet au même point ; essayer de retirer chaque objet et d’en ajouter un nouveau.

6. Envoyer :

   ```text
   /210001 A|clear
   ```

7. Tester detachme depuis le seul contrôleur T temporaire et vérifier la disparition sans demande de restauration d’inventaire.

**Résultat attendu :** detach sans option protège son propre linkset ; detach:point protège ajout et retrait de ce point. Les locks restent valables pour detachme ; T temporaire utilise le retrait d’objet local au simulateur, sans restaurer un inventaire inexistant.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `detach`, `detachme`.

<a id="w05"></a>
## W05 — Verrous partagés/non partagés et portée des dossiers

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@sharedwear=n,unsharedunwear=n
   ```

2. Essayer de porter depuis #RLV et de retirer hors #RLV ; tester les opérations inverses.

3. Envoyer :

   ```text
   /210001 A|clear
   ```

4. Envoyer :

   ```text
   /210001 A|@sharedunwear=n,unsharedwear=n
   ```

5. Refaire.

6. Envoyer :

   ```text
   /210001 A|clear
   ```

7. Envoyer :

   ```text
   /210001 A|@attachthis:RLVa Validation/Locked=n,detachthis:RLVa Validation/Locked=n
   ```

8. Essayer sur les éléments directs puis dans le sous-dossier ; répéter avec attachallthis/detachallthis.

9. Ajouter les exceptions attachthis_except/attachallthis_except/detachthis_except/detachallthis_except au même émetteur puis à B ; tester les portées et le verrou ancêtre le plus proche.

**Résultat attendu :** Les restrictions distinguent partagé/non partagé et dossier direct/sous-arbre. Une exception d’un autre émetteur ne libère pas arbitrairement un verrou d’A. Les liens de dossier traversent les bornes natives sans récursion illimitée.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sharedwear`, `sharedunwear`, `unsharedwear`, `unsharedunwear`, `attachthis`, `attachallthis`, `detachthis`, `detachallthis`, `attachthis_except`, `attachallthis_except`, `detachthis_except`, `detachallthis_except`.

<a id="w06"></a>
## W06 — Déplacements, copies, renommages et liens sous locks

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Verrouiller un dossier ou sous-arbre de test avec attachallthis/detachallthis.

2. Déplacer un original et un dossier entre deux zones de même type de verrou puis entre zones de types différents ; essayer copie, suppression et déplacement de lien.

3. Créer un lien de dossier vers une destination cachée et un autre vers un dossier visible.

4. Relever l’arborescence après confirmation serveur, pas seulement la sélection du viewer.

**Résultat attendu :** Les mutations ne permettent pas de sortir d’une protection en changeant de parent ; mouvements permis entre états de verrou équivalents. Les liens cachés n’exposent pas de contenu. Comparer précisément les originaux et les liens.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachallthis`, `detachallthis`.

<a id="w07"></a>
## W07 — Nostrip : casse, originaux et parents repliés

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Utiliser les copies de test nostrip, NOSTRIP, lien portant seul le mot nostrip, parent contenant nostrip, parent replié et ancêtre ordinaire plus haut.

2. Forcer leur retrait avec les variantes detach/remoutfit appropriées.

3. Tenter ensuite le retrait manuel et detachme depuis l’accessoire marqué lui-même.

4. Relever séparément chaque copie pour éviter de conclure à partir d’un seul nom.

**Résultat attendu :** nostrip est sensible à la casse sur l’original et les parents natifs pertinents ; le libellé d’un lien seul ou un ancêtre ordinaire éloigné ne crée pas ce verrou. Le retrait manuel est distinct du retrait scripté ; detachme peut exempter son propre nostrip mais pas un lock d’attache.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `detach`, `remoutfit`, `detachme`.

<a id="w08"></a>
## W08 — Noms repliés, liens, gestes et préfixes de port

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Dans les dossiers Simple, Nested, .(chest), Hidden, le lien FolderLink et les noms littéraux . et .. de FIXTURES : demander getinv/getinvworn puis tester attachall/attachallover et detachall.

2. Activer/désactiver les noms legacy et le port partagé sans nom, puis répéter sur l’accessoire sans suffixe et sur l’original no-modify.

3. Configurer les préfixes d’ajout/remplacement ; comparer les dossiers +Add et Replace, puis tester un préfixe vide et un préfixe commençant par un point.

4. Restaurer les réglages après le test.

**Résultat attendu :** Collecteur de port et requêtes cohérents : liens de dossiers à un niveau, contenu replié sans descente récursive arbitraire, gestes inclus, règles de noms/permissions de l’original respectées. Les préfixes changent ajout/remplacement selon leur configuration exacte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachall`, `attachallover`, `detachall`, `getinv`, `getinvworn`.

**Réglages couverts :** `legacy_naming`, `shared_wear`, `wear_add_prefix`, `wear_replace_prefix`.

<a id="w09"></a>
## W09 — Masquage de présence verrouillée et émetteur demandeur

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Porter une chemise et un accessoire de test ; verrouiller leur retrait depuis A.

2. Depuis B, demander getattach/getoutfit, puis refaire les requêtes depuis A.

3. Activer séparément le masquage des attaches puis des couches verrouillées.

4. Comparer avec les couches de corps et les noms de points/couches.

5. Désactiver les deux options et refaire.

**Résultat attendu :** Le masquage modifie les réponses visées pour les autres demandeurs ; l’émetteur qui demande sa propre protection est exempté selon la référence. Les couches de corps ne disparaissent pas comme des vêtements ordinaires. Le masquage ne libère aucun verrou.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getattach`, `getoutfit`, `getattachnames`, `getoutfitnames`.

**Réglages couverts :** `hide_locked_attachments`, `hide_locked_layers`.

<a id="w10"></a>
## W10 — Remplacement avec prédécesseur verrouillé et point inconnu

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Porter deux accessoires au même point ; verrouiller seulement l’un.

2. Avec « remplacer les éléments non verrouillés » activé, remplacer par une copie de test ; vérifier ancien verrouillé conservé et ancien libre retiré.

3. Désactiver l’option et retenter : le remplacement du point verrouillé doit être refusé.

4. Répéter via tenue COF et objet dont le point réel n’est connu qu’après l’arrivée ; attendre les confirmations.

5. Tester le déplacement d’un accessoire porté vers un autre point sans pouvoir retirer son ancien point.

**Résultat attendu :** Le réglage natif choisit conservation des prédécesseurs verrouillés ou refus strict du remplacement. Une arrivée sur point tardivement connu est re-vérifiée, sans dépouiller l’élément verrouillé ni restaurer au mauvais point.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addattach`, `remattach`, `detach`.

**Réglages couverts :** `replace_unlocked`.

<a id="w11"></a>
## W11 — Renommage automatique confirmé

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Désactiver le port partagé sans nom, activer le renommage automatique, puis porter un original modifiable nouvellement ajouté à #RLV.

2. Porter ensuite un original no-modify depuis un dossier partagé de test.

3. Attendre l’arrivée réelle et les métadonnées ; examiner suffixe de point et dossier .(point).

4. Renommer manuellement l’original après traitement, détacher/rattacher, puis reconnecter avec l’objet déjà porté.

5. Répéter option désactivée et pendant un disable global avant le retour d’une opération.

**Résultat attendu :** Modifiable : suffixe de point ; no-modify : dossier replié créé/réutilisé. Pas de renommage répété, pas de traitement destructif du baseline de connexion, renommage manuel ultérieur conservé. Désactivation annule le workflow, mais une réponse déjà acceptée met encore à jour l’inventaire ordinaire.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attach`.

**Réglages couverts :** `auto_rename`, `shared_wear`.

<a id="w12"></a>
## W12 — Cadeau #RLV, consentement et transaction

**Famille :** Inventaire. **Préconditions :** Témoin, gift-giver.lsl et charge copy+transfer.

1. Le témoin possède gift-giver.lsl avec un objet copy+transfer dans son contenu ; configurer target vers le principal.

2. Offrir le dossier par toucher ; refuser une fois, accepter une fois.

3. Vérifier création du chemin partagé, nom du dossier livré et absence de déplacement d’un objet portant un nom identique mais une autre transaction.

4. Refaire avec partage de cadeaux désactivé, puis avec désactivation globale pendant le consentement et pendant une attente de métadonnées.

5. Tester chemin inexistant, chemin déjà présent, plus de quatre composants et deux offres successives.

**Résultat attendu :** Le consentement à l’offre précède le classement. Seul le cadeau de la transaction acceptée est déplacé/renommé ; aucun classement après refus. Option désactivée : classement ordinaire. Chemin trop profond/failure borné sans boucle ni modification d’un élément homonyme. Observer le résultat confirmé par le simulateur.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `notify`.

**Réglages couverts :** `allow_shared_offers`.

<a id="w13"></a>
## W13 — Port relatif retardé et annulation

**Famille :** Inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Depuis un contrôleur dont l’arrivée d’attache n’est pas encore connue du viewer, envoyer une force relative attachthis ou detachthis.

2. Retarder sa résolution d’objet, puis laisser arriver l’attache avant 30 secondes ; vérifier le chemin original résolu et les locks à cet instant.

3. Refaire sans arrivée pendant plus de 30 secondes, puis avec clear de l’émetteur et avec disable global avant arrivée.

4. Pendant l’attente, envoyer depuis B une requête de version indépendante.

**Résultat attendu :** Attente bornée à 30 secondes pour la bonne attache, émetteur conservé, locks re-vérifiés, opérations annulées après nettoyage/disable. B continue à répondre. Si aucune arrivée réellement différée n’est produite, marquer la variante BLOQUÉE ; la course est également couverte par les tests hors ligne.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachthis`, `detachthis`, `version`.

<a id="wf01"></a>
## WF01 — attach

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attach:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attach`.

<a id="wf02"></a>
## WF02 — attachover

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachover:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachover`.

<a id="wf03"></a>
## WF03 — attachall

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachall:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachall`.

<a id="wf04"></a>
## WF04 — attachallover

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachallover:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachallover`.

<a id="wf05"></a>
## WF05 — attachoverorreplace

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachoverorreplace:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachoverorreplace`.

<a id="wf06"></a>
## WF06 — attachalloverorreplace

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachalloverorreplace:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachalloverorreplace`.

<a id="wf07"></a>
## WF07 — attachthis

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachthis=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachthis`.

<a id="wf08"></a>
## WF08 — attachallthis

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachallthis=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachallthis`.

<a id="wf09"></a>
## WF09 — attachthisover

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachthisover=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachthisover`.

<a id="wf10"></a>
## WF10 — attachallthisover

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachallthisover=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachallthisover`.

<a id="wf11"></a>
## WF11 — attachthisoverorreplace

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachthisoverorreplace=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachthisoverorreplace`.

<a id="wf12"></a>
## WF12 — attachallthisoverorreplace

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@attachallthisoverorreplace=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `attachallthisoverorreplace`.

<a id="wf13"></a>
## WF13 — addoutfit

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@addoutfit:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addoutfit`.

<a id="wf14"></a>
## WF14 — addoutfitover

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@addoutfitover:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addoutfitover`.

<a id="wf15"></a>
## WF15 — addoutfitall

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@addoutfitall:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addoutfitall`.

<a id="wf16"></a>
## WF16 — addoutfitallover

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@addoutfitallover:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addoutfitallover`.

<a id="wf17"></a>
## WF17 — addoutfitthis

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@addoutfitthis=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addoutfitthis`.

<a id="wf18"></a>
## WF18 — addoutfitallthis

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@addoutfitallthis=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addoutfitallthis`.

<a id="wf19"></a>
## WF19 — addoutfitthisover

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@addoutfitthisover=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addoutfitthisover`.

<a id="wf20"></a>
## WF20 — addoutfitallthisover

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@addoutfitallthisover=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addoutfitallthisover`.

<a id="wf21"></a>
## WF21 — detachthis

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@detachthis=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `detachthis`.

<a id="wf22"></a>
## WF22 — detachallthis

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@detachallthis=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `detachallthis`.

<a id="wf23"></a>
## WF23 — detach

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@detach:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `detach`.

<a id="wf24"></a>
## WF24 — detachall

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@detachall:RLVa Validation/Simple=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `detachall`.

<a id="wf25"></a>
## WF25 — detachme

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@detachme=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `detachme`.

<a id="wf26"></a>
## WF26 — remattach

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@remattach:chest=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `remattach`.

<a id="wf27"></a>
## WF27 — remoutfit

**Famille :** Forces d’inventaire. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer uniquement les copies de Simple ; pour une forme this, porter A depuis Simple afin que sa racine relative soit connue.

2. Envoyer :

   ```text
   /210001 A|@remoutfit:shirt=force
   ```

3. Relever chaque lien COF, geste et point avant/après confirmation.

4. Refaire avec un élément de destination verrouillé par A, puis par B.

5. Refaire sur un dossier avec un sous-dossier pour distinguer all/direct ; pour over/overorreplace, garder un prédécesseur libre puis verrouillé.

**Résultat attendu :** Comparer la sémantique spécifique de cette forme : ajout/remplacement, dossier direct/tout le sous-arbre, relatif/explicite. Les opérations d’inventaire forcées respectent les verrous applicables, y compris ceux de leur émetteur ; detachme conserve ses règles propres. Aucun test global ne remplace le relevé de chaque variante.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `remoutfit`.

<a id="k01"></a>
## K01 — Propriétaire exclusif, offsets et préférences

**Famille :** Caméra. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@setcam=n,setcam_eyeoffset:-4/0/1=n,setcam_focusoffset:0/0/1=n,setcam_eyeoffsetscale:1.2=n
   ```

2. Envoyer :

   ```text
   /210001 B|@setcam=n,setcam_eyeoffset:-10/0/3=n
   ```

3. Essayer les presets, offsets, raccourcis et contrôles de caméra du viewer.

4. Envoyer :

   ```text
   /210001 A|@setcam_eyeoffset:-3/0/2=force,setcam_focusoffset:0/0/0.5=force,setcam_eyeoffsetscale:1=force
   ```

5. Vérifier le maintien du propriétaire A.

6. Envoyer :

   ```text
   /210001 A|clear
   ```

7. Observer l’état restant de B, puis nettoyer B et vérifier le retour aux préférences initiales.

**Résultat attendu :** Premier propriétaire exclusif prioritaire ; un autre émetteur ne prend pas silencieusement le contrôle. Les mutations par presets/préférences sont interdites lorsque l’offset approprié est verrouillé. Libération suit le modèle natif, sans sauvegarder ces valeurs de session comme préférences utilisateur.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setcam`, `setcam_eyeoffset`, `setcam_focusoffset`, `setcam_eyeoffsetscale`.

<a id="k02"></a>
## K02 — Bornes avatar/origine et alias legacy

**Famille :** Caméra. **Préconditions :** Compte principal, contrôleurs A et B.

1. Interroger getcam_avdist, getcam_avdistmin, getcam_avdistmax avant toute restriction.

2. Pour chaque paire setcam_avdistmin/max et setcam_origindistmin/max : tester une limite seule, les deux, puis deux émetteurs avec bornes contradictoires ; déplacer/zoomer l’avatar et la caméra.

3. Recommencer camdistmin/max, les retirer par leur nom exact puis vérifier qu’un alias indépendant n’a pas été supprimé.

4. Tester camunlock et setcam_unlock pendant un déplacement de focus.

**Résultat attendu :** Requêtes de limites inactives vides ; actives à trois décimales. Bornes appliquées au bon espace (avatar/origine), règles multiples combinées selon la référence. Les noms/alias gardent leurs suppressions indépendantes.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setcam_avdistmin`, `setcam_avdistmax`, `setcam_origindistmin`, `setcam_origindistmax`, `camdistmin`, `camdistmax`, `setcam_unlock`, `camunlock`, `getcam_avdist`, `getcam_avdistmin`, `getcam_avdistmax`.

<a id="k03"></a>
## K03 — FOV, redimensionnement et restauration

**Famille :** Caméra. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@getcam_fov={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@getcam_fovmin={R}
   ```

3. Envoyer :

   ```text
   /210001 A|@getcam_fovmax={R}
   ```

4. Envoyer :

   ```text
   /210001 A|@setcam_fovmin:0.6=n,setcam_fovmax:0.9=n,setcam_fov:0.8=force
   ```

5. Redimensionner la fenêtre en formats large puis portrait ; relever l’image et les trois requêtes.

6. Envoyer :

   ```text
   /210001 A|@setcam_fov:default=force
   ```

7. Tester camzoommin/max puis les supprimer séparément.

8. Envoyer :

   ```text
   /210001 A|clear
   ```

9. Vérifier la restauration du FOV utilisateur initial et l’absence de changement au simple enable RLVa.

**Résultat attendu :** FOV et bornes respectent l’aspect de fenêtre et les limites physiques natives ; pas de vue modifiée au seul enable. Libération du dernier lock restaure le FOV initial. Valeurs malformées/non finies n’affectent pas la caméra.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setcam_fov`, `setcam_fovmin`, `setcam_fovmax`, `camzoommin`, `camzoommax`, `getcam_fov`, `getcam_fovmin`, `getcam_fovmax`.

<a id="k04"></a>
## K04 — Focus UUID/position et modes

**Famille :** Caméra. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@setcam_focus:{OBJECT}=force
   ```

2. Déplacer/redimensionner l’objet ; refaire avec PEER en mouvement pour le suivi de tête.

3. Envoyer :

   ```text
   /210001 A|@setcam_focus:{PEER};4;0/-1/0=force
   ```

4. Envoyer :

   ```text
   /210001 A|@setcam_focus:{LOCAL};2;0/-1/0=force
   ```

5. Envoyer :

   ```text
   /210001 A|@setcam_mode:mouselook=force
   ```

6. Envoyer :

   ```text
   /210001 A|@setcam_mode:thirdperson=force
   ```

7. Envoyer :

   ```text
   /210001 A|@setcam_mode:reset=force
   ```

8. Envoyer :

   ```text
   /210001 A|@setcam_mouselook=n,setcam_avdistmin:2=n
   ```

9. Essayer le mouselook natif et forcé ; retirer les locks puis refaire.

**Résultat attendu :** Focus d’objet utilise son échelle et son suivi ; avatar cible la tête posée ; focus position a sa sémantique propre. Modes et resets conformes aux valeurs natives ; les bornes/verrous mouselook ne sont pas contournés.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setcam_focus`, `setcam_mode`, `setcam_mouselook`, `setcam_avdistmin`.

<a id="v01"></a>
## V01 — blend

**Famille :** Vision. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@setsphere=n,setsphere_mode:0=force,setsphere_origin:0=force,setsphere_distmin:1=force,setsphere_distmax:6=force,setsphere_valuemin:0=force,setsphere_valuemax:1=force,setsphere_param:0.6/0.1/0.1/0=force
   ```

2. Comparer le même cadrage/profondeur près, dans et hors de l’intervalle.

3. Envoyer :

   ```text
   /210001 A|@setsphere_origin:1=force
   ```

4. Déplacer caméra puis avatar séparément.

5. Envoyer :

   ```text
   /210001 A|@setsphere_distextend:0=force
   ```

6. Répéter distextend 1, 2 et 3.

7. Envoyer :

   ```text
   /210001 A|@setsphere_tween:2=force,setsphere_distmax:10=force,setsphere_valuemax:0.5=force
   ```

8. Attendre 2 secondes ; capturer aussi une photo sans interface.

9. Envoyer :

   ```text
   /210001 A|clear
   ```

**Résultat attendu :** Effet et interpolation comparables au Legacy Viewer pour des paramètres identiques ; les origines caméra/avatar et les extensions de distance sont distinctes. L’interface/HUD demeure utilisable, l’effet participe à la photo sans UI ; nettoyage retire l’effet.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setsphere`, `setsphere_mode`, `setsphere_origin`, `setsphere_distmin`, `setsphere_distmax`, `setsphere_valuemin`, `setsphere_valuemax`, `setsphere_param`, `setsphere_distextend`, `setsphere_tween`.

<a id="v02"></a>
## V02 — flou fixe

**Famille :** Vision. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@setsphere=n,setsphere_mode:1=force,setsphere_origin:0=force,setsphere_distmin:1=force,setsphere_distmax:6=force,setsphere_valuemin:0=force,setsphere_valuemax:1=force,setsphere_param:8/0/0/0=force
   ```

2. Comparer le même cadrage/profondeur près, dans et hors de l’intervalle.

3. Envoyer :

   ```text
   /210001 A|@setsphere_origin:1=force
   ```

4. Déplacer caméra puis avatar séparément.

5. Envoyer :

   ```text
   /210001 A|@setsphere_distextend:0=force
   ```

6. Répéter distextend 1, 2 et 3.

7. Envoyer :

   ```text
   /210001 A|@setsphere_tween:2=force,setsphere_distmax:10=force,setsphere_valuemax:0.5=force
   ```

8. Attendre 2 secondes ; capturer aussi une photo sans interface.

9. Envoyer :

   ```text
   /210001 A|clear
   ```

**Résultat attendu :** Effet et interpolation comparables au Legacy Viewer pour des paramètres identiques ; les origines caméra/avatar et les extensions de distance sont distinctes. L’interface/HUD demeure utilisable, l’effet participe à la photo sans UI ; nettoyage retire l’effet.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setsphere`, `setsphere_mode`, `setsphere_origin`, `setsphere_distmin`, `setsphere_distmax`, `setsphere_valuemin`, `setsphere_valuemax`, `setsphere_param`, `setsphere_distextend`, `setsphere_tween`.

<a id="v03"></a>
## V03 — flou variable

**Famille :** Vision. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@setsphere=n,setsphere_mode:2=force,setsphere_origin:0=force,setsphere_distmin:1=force,setsphere_distmax:6=force,setsphere_valuemin:0=force,setsphere_valuemax:1=force,setsphere_param:12/0/0/0=force
   ```

2. Comparer le même cadrage/profondeur près, dans et hors de l’intervalle.

3. Envoyer :

   ```text
   /210001 A|@setsphere_origin:1=force
   ```

4. Déplacer caméra puis avatar séparément.

5. Envoyer :

   ```text
   /210001 A|@setsphere_distextend:0=force
   ```

6. Répéter distextend 1, 2 et 3.

7. Envoyer :

   ```text
   /210001 A|@setsphere_tween:2=force,setsphere_distmax:10=force,setsphere_valuemax:0.5=force
   ```

8. Attendre 2 secondes ; capturer aussi une photo sans interface.

9. Envoyer :

   ```text
   /210001 A|clear
   ```

**Résultat attendu :** Effet et interpolation comparables au Legacy Viewer pour des paramètres identiques ; les origines caméra/avatar et les extensions de distance sont distinctes. L’interface/HUD demeure utilisable, l’effet participe à la photo sans UI ; nettoyage retire l’effet.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setsphere`, `setsphere_mode`, `setsphere_origin`, `setsphere_distmin`, `setsphere_distmax`, `setsphere_valuemin`, `setsphere_valuemax`, `setsphere_param`, `setsphere_distextend`, `setsphere_tween`.

<a id="v04"></a>
## V04 — aberration chromatique

**Famille :** Vision. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@setsphere=n,setsphere_mode:3=force,setsphere_origin:0=force,setsphere_distmin:1=force,setsphere_distmax:6=force,setsphere_valuemin:0=force,setsphere_valuemax:1=force,setsphere_param:0.01/0.01/0/0=force
   ```

2. Comparer le même cadrage/profondeur près, dans et hors de l’intervalle.

3. Envoyer :

   ```text
   /210001 A|@setsphere_origin:1=force
   ```

4. Déplacer caméra puis avatar séparément.

5. Envoyer :

   ```text
   /210001 A|@setsphere_distextend:0=force
   ```

6. Répéter distextend 1, 2 et 3.

7. Envoyer :

   ```text
   /210001 A|@setsphere_tween:2=force,setsphere_distmax:10=force,setsphere_valuemax:0.5=force
   ```

8. Attendre 2 secondes ; capturer aussi une photo sans interface.

9. Envoyer :

   ```text
   /210001 A|clear
   ```

**Résultat attendu :** Effet et interpolation comparables au Legacy Viewer pour des paramètres identiques ; les origines caméra/avatar et les extensions de distance sont distinctes. L’interface/HUD demeure utilisable, l’effet participe à la photo sans UI ; nettoyage retire l’effet.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setsphere`, `setsphere_mode`, `setsphere_origin`, `setsphere_distmin`, `setsphere_distmax`, `setsphere_valuemin`, `setsphere_valuemax`, `setsphere_param`, `setsphere_distextend`, `setsphere_tween`.

<a id="v05"></a>
## V05 — pixellisation

**Famille :** Vision. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@setsphere=n,setsphere_mode:4=force,setsphere_origin:0=force,setsphere_distmin:1=force,setsphere_distmax:6=force,setsphere_valuemin:0=force,setsphere_valuemax:1=force,setsphere_param:12/0/0/0=force
   ```

2. Comparer le même cadrage/profondeur près, dans et hors de l’intervalle.

3. Envoyer :

   ```text
   /210001 A|@setsphere_origin:1=force
   ```

4. Déplacer caméra puis avatar séparément.

5. Envoyer :

   ```text
   /210001 A|@setsphere_distextend:0=force
   ```

6. Répéter distextend 1, 2 et 3.

7. Envoyer :

   ```text
   /210001 A|@setsphere_tween:2=force,setsphere_distmax:10=force,setsphere_valuemax:0.5=force
   ```

8. Attendre 2 secondes ; capturer aussi une photo sans interface.

9. Envoyer :

   ```text
   /210001 A|clear
   ```

**Résultat attendu :** Effet et interpolation comparables au Legacy Viewer pour des paramètres identiques ; les origines caméra/avatar et les extensions de distance sont distinctes. L’interface/HUD demeure utilisable, l’effet participe à la photo sans UI ; nettoyage retire l’effet.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setsphere`, `setsphere_mode`, `setsphere_origin`, `setsphere_distmin`, `setsphere_distmax`, `setsphere_valuemin`, `setsphere_valuemax`, `setsphere_param`, `setsphere_distextend`, `setsphere_tween`.

<a id="v06"></a>
## V06 — Ordre, six sphères et limites de ressources

**Famille :** Vision. **Préconditions :** Sept émetteurs distincts et captures comparables.

1. Créer des contrôleurs distincts A à G et leur envoyer chacun setsphere=n avec une couleur/mode différent ; noter l’ordre d’activation.

2. Vérifier six effets actifs ; tenter un septième, supprimer l’un des six puis refaire le septième.

3. Enregistrer les ordres inversés et les effets superposés ; comparer aux références sans confondre l’ordre d’UUID et l’ordre d’activation.

4. Tester un rayon de flou très supérieur à 256 pixels dans le test spécifique de divergence ; arrêter le test si la référence devient inutilisable.

**Résultat attendu :** Au plus six sphères actives, ordre d’activation respecté, ressources libérées à la suppression. Le plafond GPU de noyau variable à 256 pixels est une divergence connue à enregistrer explicitement, pas une preuve de parité pour les valeurs extrêmes.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setsphere`, `setsphere_color`, `setsphere_param`.

<a id="v07"></a>
## V07 — Overlay, masque alpha, teinte et tween

**Famille :** Vision. **Préconditions :** Texture de masque connue et objets derrière chaque bande.

1. Configurer TEXTURE avec l’asset UUID de assets/overlay-mask.png importé.

2. Envoyer :

   ```text
   /210001 A|@setoverlay=n,setoverlay_texture:{TEXTURE}=force,setoverlay_alpha:1=force,setoverlay_tint:1/1/1=force,setoverlay_touch=n
   ```

3. Cliquer un objet derrière chaque bande alpha 0, 32, 33 et 255, loin des frontières ; cliquer aussi le terrain, un HUD et l’UI.

4. Envoyer :

   ```text
   /210001 A|@setoverlay_tween:0.2;1/0.5/0.5;2=force
   ```

5. Observer l’évolution pendant 2 secondes puis prendre une photo sans UI.

6. Envoyer :

   ```text
   /210001 A|clear
   ```

**Résultat attendu :** Masque de hit testé sur les trous et les zones opaques ; seuil natif >32/255 et échantillonnage par blocs de deux pixels. L’overlay est après les étiquettes du monde et avant les HUDs, présent sur les photos. Le terrain, les HUDs et l’UI gardent leurs chemins prévus. La grammaire tween est alpha;R/G/B;durée.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setoverlay`, `setoverlay_texture`, `setoverlay_alpha`, `setoverlay_tint`, `setoverlay_tween`, `setoverlay_touch`.

<a id="v08"></a>
## V08 — Priorité d’overlay et linkset

**Famille :** Vision. **Préconditions :** Deux textures et un linkset avec deux enfants.

1. Configurer A et B avec deux textures d’overlay différentes et activer A puis B.

2. Supprimer A puis réactiver A après B ; noter l’overlay gagnant.

3. Placer C dans un enfant du linkset de B et D dans un autre ; activer leurs overlays, modifier l’ordre de liens puis répéter après nettoyage.

4. Détacher/faire disparaître le gagnant et attendre son nettoyage.

**Résultat attendu :** Arbitrage par linkset et ordre/numéro de liens conforme à la référence ; un objet ne modifie pas l’overlay d’un autre. Disparition ou clear libère la bonne priorité.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setoverlay`, `setoverlay_texture`.

<a id="v09"></a>
## V09 — Textures forcées, avatar propre et silhouettes

**Famille :** Vision. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@setcam_textures:{TEXTURE}=n
   ```

2. Envoyer :

   ```text
   /210001 A|@getcam_textures={R}
   ```

3. Observer objets diffus/PBR et particules, avatars et attaches.

4. Envoyer :

   ```text
   /210001 A|@setcam_textures:{TEXTURE}=y,camtextures=n
   ```

5. Envoyer :

   ```text
   /210001 A|@getcam_textures={R}
   ```

6. Envoyer :

   ```text
   /210001 A|clear
   ```

7. Tester séparément showself=n, showselfhead=n et leur libération, en troisième personne et mouselook.

8. Envoyer :

   ```text
   /210001 A|@setcam_avdist:4=n
   ```

9. Déplacer le témoin avant/après 4 m ; refaire avec camavdist et avec une exception de rendu courante dans le viewer.

**Résultat attendu :** Textures de monde/particules remplacées sans remplacer arbitrairement avatars/attaches ; getter reflète l’override. Corps/tête propres respectent la commande et la caméra, HUD visible. Silhouette sombre distante prioritaire sur les exceptions de rendu ; alias et libération cohérents.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setcam_textures`, `camtextures`, `getcam_textures`, `showself`, `showselfhead`, `setcam_avdist`, `camavdist`.

<a id="d01"></a>
## D01 — Fenêtres, nametags et hover text

**Famille :** Confidentialité. **Préconditions :** Compte principal, contrôleurs A et B.

1. Ouvrir inventaire, minimap et carte, puis A|@showinv=n,showminimap=n,showworldmap=n.

2. Essayer de rouvrir chaque fenêtre par ses entrées usuelles.

3. Tester shownametags=n puis shownametags:10=n et une exception pour PEER, avec des témoins à plusieurs distances.

4. Tester séparément showhovertextall, showhovertextworld, showhovertexthud et showhovertext:OBJECT, depuis une racine puis un enfant possédant son propre texte flottant.

5. Supprimer les restrictions et refaire.

**Résultat attendu :** Fenêtres déjà ouvertes et nouvelles ouvertures suivent les locks. Les noms au-dessus des avatars obéissent aux exceptions/rayons sans masquer son propre nom à tort. Hovertext ciblé est spécifique au prim, contrairement aux règles de toucher qui portent sur le linkset.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `showinv`, `showminimap`, `showworldmap`, `shownametags`, `showhovertextall`, `showhovertextworld`, `showhovertexthud`, `showhovertext`.

<a id="d02"></a>
## D02 — Identités, URLs, menus et proximité

**Famille :** Confidentialité. **Préconditions :** Compte principal, contrôleurs A et B.

1. Préparer un message contenant noms Unicode, display name, username, URL encodée de profil et plusieurs noms dont l’un est inclus dans un autre.

2. Envoyer :

   ```text
   /210001 A|@shownames=n,shownearby=n
   ```

3. Examiner Conversations, Personnes/Nearby, radar, notifications, hovertexts et noms de liens ; ouvrir les menus et liens des avatars masqués.

4. Ouvrir un profil/IM avant d’ajouter la restriction puis refaire ; tester une résolution de nom qui arrive après le verrou.

5. Envoyer :

   ```text
   /210001 A|@shownames:{PEER}=n
   ```

6. Refaire avec shownames_sec et deux émetteurs, puis nettoyer.

**Résultat attendu :** Projection d’affichage cohérente, menus limités et liens protégés ; listes de proximité masquées. Correspondances Unicode/URLs et noms inclus traitées sans fuite. Les identités canoniques internes/transcripts sont distinctes de l’affichage ; comparer leur traitement natif sans publier de données personnelles.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `shownames`, `shownearby`.

<a id="d03"></a>
## D03 — Localisation, historique et nouvelles écritures

**Famille :** Confidentialité. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@showloc=n
   ```

2. Examiner barre de lieu, carte, historique de TP, cartes d’invitation et détails Places ; copier/ouvrir les liens de lieu par chaque entrée courante.

3. Essayer de créer un landmark, un pick et une petite annonce avec la position actuelle ; essayer seulement de modifier le texte d’une entrée existante.

4. Envoyer une offre de TP à un témoin ordinaire, un ami en ligne ayant le droit carte, et un témoin listé comme exception tplure.

5. Libérer showloc puis vérifier l’étiquette de lieu et l’historique sans changer les coordonnées de destination.

**Résultat attendu :** Position courante masquée et non réécrite par une nouvelle entrée révélatrice ; entrées existantes restent modifiables dans les limites natives. Destinataires d’offres filtrés individuellement, exceptions permissives tplure et droits carte respectés. La position réelle n’est pas falsifiée pour masquer l’étiquette.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `showloc`, `tplure`.

<a id="a01"></a>
## A01 — Toucher : chaque catégorie, exceptions et bornes

**Famille :** Actions. **Préconditions :** Compte principal, contrôleurs A et B.

1. Utiliser cible rezzée, accessoire propre normal, accessoire du témoin, HUD propre et linkset enfant.

2. Pour touchall, touchworld, touchattach, touchattachself, touchattachother, touchhud : imposer chaque restriction séparément, cliquer chaque catégorie puis supprimer.

3. Tester touchthis:OBJECT, exceptions touchworld:OBJECT et touchattach:OBJECT/PEER, et touchattachother:PEER.

4. Imposer touchme=n depuis l’objet cible ou son enfant ; vérifier les dérogations de linkset prévues.

5. Tester interact=n et fartouch:2=n ; cliquer la surface à 1,99 m, 2,00 m et 2,01 m, puis répéter avec touchfar.

6. Comparer le centre et la surface d’un grand objet pour prouver que le point touché est utilisé.

**Résultat attendu :** Racine de linkset pour les locks de toucher, prim/surface pour la distance ; distinctions propre/autre/HUD exactes, touchme sur le bon linkset. La borne de fartouch est inclusive, les HUDs/attaches propres suivent leurs exemptions natives.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `touchall`, `touchworld`, `touchattach`, `touchattachself`, `touchattachother`, `touchhud`, `touchthis`, `touchme`, `interact`, `fartouch`, `touchfar`.

<a id="a02"></a>
## A02 — Buy, pay et rez

**Famille :** Actions. **Préconditions :** Cibles de test vendables/payables ; transactions facultatives à décider manuellement.

1. Envoyer :

   ```text
   /210001 A|@buy=n
   ```

2. Sur une cible rezzée vendue et acceptant des paiements, essayer Acheter et Payer ; essayer le paiement d’avatar séparément.

3. Envoyer :

   ```text
   /210001 A|clear
   ```

4. Envoyer :

   ```text
   /210001 A|@pay=n
   ```

5. Refaire les deux paiements et Acheter. Ouvrir/annuler suffit pour les contrôles UI ; noter séparément les transactions positives réellement exécutées avec accord des témoins.

6. Envoyer :

   ```text
   /210001 A|@rez=n
   ```

7. Essayer création de prim, rez depuis inventaire et duplication ; refaire après suppression.

**Résultat attendu :** Buy protège achat/paiement d’objet ; pay protège paiement d’avatar/groupe. Rez bloque création/rez/duplication. Les contrôles réseau sont aussi testés hors ligne : un test UI seul ne prouve pas qu’un paquet a été envoyé/refusé.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `buy`, `pay`, `rez`.

<a id="a03"></a>
## A03 — Édition et mutations : prim, matériau, média, scripts

**Famille :** Actions. **Préconditions :** Compte principal, contrôleurs A et B.

1. Ouvrir une sélection avant les restrictions ; tester edit=n, puis une exception edit:OBJECT.

2. Tester editobj:OBJECT, editattach=n et editworld=n séparément sur racines/enfants, objet rezzé et accessoire.

3. Essayer déplacement/rotation/échelle, formes, textures, matériau PBR/legacy, paramètres média, noms/descriptions/flags, liens/déliens, inventaire de tâche et scripts.

4. Depuis une sélection autorisée, ajouter une restriction pendant un retour de cap/métadonnées retardé.

5. Tester surlignage de transparence et wireframe ; puis showloc=n pour la transparence.

**Résultat attendu :** Désélection/édition locale et écritures réseau partagent le contrôle applicable ; une fenêtre déjà ouverte ne contourne pas un verrou. Les requêtes de lecture/libération restent possibles. edit/showloc empêchent aussi la mise en évidence des faces transparentes.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `edit`, `editobj`, `editattach`, `editworld`, `viewtransparent`, `viewwireframe`.

<a id="a04"></a>
## A04 — Documents déjà ouverts et brouillons

**Famille :** Actions. **Préconditions :** Compte principal, contrôleurs A et B.

1. Ouvrir une texture, une notecard et un script de test ; saisir un brouillon non sauvegardé dans les éditeurs.

2. Envoyer :

   ```text
   /210001 A|@viewtexture=n,viewnote=n,viewscript=n
   ```

3. Essayer les ouvertures depuis inventaire, contenu d’objet et liens ; examiner les éditeurs déjà ouverts.

4. Envoyer :

   ```text
   /210001 A|clear
   ```

5. Vérifier le retour des documents et la conservation du brouillon avant de fermer volontairement.

**Résultat attendu :** Le contenu déjà ouvert est masqué et les nouvelles lectures d’affichage sont bloquées ; les brouillons ne sont pas détruits à cause du verrou.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `viewtexture`, `viewnote`, `viewscript`.

<a id="a05"></a>
## A05 — HUD verrouillé et modes de rendu

**Famille :** Actions. **Préconditions :** Compte principal, contrôleurs A et B.

1. Porter un HUD de test à un point connu ; ajouter remattach:nom_du_point=n depuis A.

2. Essayer de masquer les HUDs et d’activer le wireframe par menu, raccourci et préférences ; vérifier le rendu réellement obtenu.

3. Remplacer le verrou de retrait par addattach:point=n seulement, puis par un verrou sur un point ordinaire sans HUD.

4. Refaire avec un HUD temporaire, puis un HUD dans un dossier verrouillé.

5. Prendre une photo avec/sans HUD via les réglages de photo natifs, distincts du commutateur de visibilité HUD ordinaire.

**Résultat attendu :** Un HUD effectivement verrouillé au retrait garde la visibilité HUD ordinaire et interdit wireframe. Un lock d’ajout seul ou sur un autre point ne suffit pas. Le chemin photo conserve sa sémantique propre ; ne pas confondre photo sans HUD et masquage interactif général.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `remattach`, `addattach`, `detach`, `viewwireframe`.

<a id="g01"></a>
## G01 — Activation par UUID, nom et rôle

**Famille :** Groupes. **Préconditions :** Compte membre de deux groupes de test, droits de titre/rôle appropriés.

1. Noter le groupe/titre initial.

2. Envoyer :

   ```text
   /210001 A|@getgroup={R}
   ```

3. Envoyer :

   ```text
   /210001 A|@setgroup:{GROUP}=force
   ```

4. Envoyer :

   ```text
   /210001 A|@getgroup={R}
   ```

5. Envoyer :

   ```text
   /210001 A|@setgroup:{GROUPNAME};{ROLE}=force
   ```

6. Tester un nom exact, un préfixe ambigu et un rôle nécessitant un chargement de métadonnées ; attendre plus de 60 secondes entre forces quand nécessaire.

7. Envoyer :

   ```text
   /210001 A|@setgroup=n
   ```

8. Essayer changement utilisateur, titre et changement déclenché par un script de la région.

9. Envoyer :

   ```text
   /210001 B|@setgroup:{GROUP}=force
   ```

10. Envoyer :

   ```text
   /210001 A|@setgroup:none=force
   ```

11. Supprimer le lock et rétablir le groupe initial.

**Résultat attendu :** UUID membre et noms/rôles résolus selon les priorités natives, pas d’activation d’un groupe inconnu. Cadence de 60 s et première exception du propriétaire de lock respectées. Les changements interdits sont empêchés/restaurés sans boucle ; les callbacks gardent l’émetteur.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setgroup`, `getgroup`.

<a id="g02"></a>
## G02 — Acceptpermission : contrôle, attache et propriété réelle

**Famille :** Permissions. **Préconditions :** Sondes rezzées détenues par principal et témoin ; principal consentant.

1. Utiliser permission-probe.lsl dans un prim rezzé appartenant au principal ; ni porté ni siège utilisé. Choisir controls ; toucher sans acceptpermission et relever la demande.

2. Réinitialiser la sonde puis A|@acceptpermission=n ; refaire controls, attach, animation et teleport, séparément.

3. Refaire attach depuis une sonde appartenant au témoin, avec TARGET principal et toucher volontaire du principal.

4. Recommencer la variante portée seulement pour relever les auto-grants du simulateur, distincts d’un traitement viewer.

5. Comparer les masques granted, la présence des cartes et les dialogues restants ; révoquer/réinitialiser chaque sonde entre essais.

**Résultat attendu :** Acceptpermission n’auto-accepte que les permissions natives éligibles : controls si objet connu, attach pour objet rezzé possédé. Animation/teleport restent des questions ordinaires. Le flag de propriété serveur, non la disponibilité d’un inventaire, détermine le cas. Un auto-grant serveur sur une attache ne prouve pas le comportement du viewer.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `acceptpermission`.

<a id="g03"></a>
## G03 — Attacher n’exige qu’un point réellement libre

**Famille :** Permissions. **Préconditions :** Sonde de permissions rezzée et inventaire/avatars chargés.

1. Choisir attach sur la sonde rezzée ; réinitialiser entre demandes.

2. Envoyer :

   ```text
   /210001 A|@addattach:chest=n
   ```

3. Toucher la sonde et relever la permission restante.

4. Envoyer :

   ```text
   /210001 A|@addattach:,
   ```

5.     =n,addattach:,

6.     =n,addattach:,

7.     =n,addattach:,

8.     =n,addattach:,

9.     =n,addattach:,

10.     =n,addattach:,

11.     =n,addattach:,

12.     =n,addattach:,

13.     =n,addattach:,

14.     =n,addattach:,

15.     =n,addattach:,

16.     =n

17. Envoyer :

   ```text
   /210001 A|@addattach:,
   ```

18.     =n,addattach:,

19.     =n,addattach:,

20.     =n,addattach:,

21.     =n,addattach:,

22.     =n,addattach:,

23.     =n,addattach:,

24.     =n,addattach:,

25.     =n,addattach:,

26.     =n,addattach:,

27.     =n,addattach:,

28.     =n,addattach:,

29.     =n

30. Envoyer :

   ```text
   /210001 A|@addattach:,
   ```

31.     =n,addattach:,

32.     =n,addattach:,

33.     =n,addattach:,

34.     =n,addattach:,

35.     =n,addattach:,

36.     =n,addattach:,

37.     =n,addattach:,

38.     =n,addattach:,

39.     =n,addattach:,

40.     =n,addattach:,

41.     =n,addattach:,

42.     =n

43. Envoyer :

   ```text
   /210001 A|@addattach:,
   ```

44.     =n,addattach:,

45.     =n,addattach:,

46.     =n,addattach:,

47.     =n,addattach:,

48.     =n,addattach:,

49.     =n,addattach:,

50.     =n,addattach:,

51.     =n,addattach:,

52.     =n,addattach:,

53.     =n,addattach:,

54.     =n,addattach:,

55.     =n

56. Envoyer :

   ```text
   /210001 A|@addattach:,
   ```

57.     =n,addattach:,

58.     =n,addattach:,

59.     =n,addattach:,

60.     =n,addattach:,

61.     =n,addattach:,

62.     =n

63. Toucher à nouveau : relever le masque filtré et l’absence de dialogue inutile.

64. Envoyer :

   ```text
   /210001 A|@addattach:skull=y
   ```

65. Refaire la demande. Répéter en utilisant detach:point=n sur une partie des points au lieu de addattach.

66. Envoyer :

   ```text
   /210001 A|@tploc=n
   ```

67. Demander teleport seul puis combined (attach|teleport) ; relever les bits conservés.

**Résultat attendu :** Un seul point verrouillé n’interdit pas globalement PERMISSION_ATTACH ; tous les points réellement verrouillés retirent le bit. Une ouverture réautorise la question. Detach:point participe aux locks d’ajout. Tploc retire PERMISSION_TELEPORT ; les autres bits éligibles restent traités normalement.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `addattach`, `detach`, `tploc`, `acceptpermission`.

<a id="g04"></a>
## G04 — Permissions de prudence et expérience

**Famille :** Permissions. **Préconditions :** Sonde caution séparée ; expérience de test pour sa sous-variante.

1. Envoyer :

   ```text
   /210001 A|@acceptpermission=n
   ```

2. Dans une copie rezzée contenant uniquement caution-probe.lsl, toucher volontairement pour demander la question de débit ; choisir REFUSER.

3. Vérifier qu’aucun accord automatique n’a été donné. La sonde n’exécute aucune fonction de paiement et révoque tout accord inattendu.

4. Tester séparément une demande d’expérience avec experience-attachment.lsl ; relever la carte de consentement propre à l’expérience avant toute attache.

5. Réinitialiser/supprimer les copies de sonde après relevé.

**Résultat attendu :** Les permissions de prudence et la participation à une expérience gardent leur consentement natif ; acceptpermission ne les accepte pas silencieusement. Le résultat attendu pour la sonde caution refusée est granted=0.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `acceptpermission`.

<a id="g05"></a>
## G05 — Sans expérience : acceptation et option globale

**Famille :** Attaches temporaires. **Préconditions :** Objet T transférable, deux scripts fournis, emplacement disponible.

1. Créer T rezzé avec controller.lsl (description T) et temporary-attachment.lsl ; objet transférable.

2. Toucher T et accepter la permission d’attache ; relever son UUID et l’absence de nouvel original d’inventaire.

3. Désactiver les contrôleurs temporaires dans les préférences.

4. Envoyer :

   ```text
   /210001 T|@jump=n,version={R}
   ```

5. Vérifier saut libre, OwnerSay brut et aucune réponse.

6. Réactiver l’option ; refaire la commande et vérifier la restriction/réponse.

7. Désactiver à nouveau ; T|@clear ; vérifier que cette commande est aussi ignorée et que l’ancienne règle n’est pas supprimée rétroactivement.

8. Réactiver et T|clear, puis retirer T.

**Résultat attendu :** Le gate concerne toute attache temporaire selon ses métadonnées natives, sans exiger une expérience. Option off bloque aussi query et clear de cette source ; les règles antérieures persistent jusqu’au nettoyage approprié. Un accessoire d’inventaire ordinaire et un objet rezzé ne sont pas filtrés à tort.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `jump`, `version`.

**Réglages couverts :** `temporary_controllers`.

<a id="g06"></a>
## G06 — Expérience : seuil, liste et identification tardive

**Famille :** Attaches temporaires. **Préconditions :** Expérience(s) dont le testeur est contributeur, parcelle qui les autorise ; accès aux ratings utiles.

1. Utiliser T avec experience-attachment.lsl à la place du script temporaire ordinaire ; compiler ce script dans votre expérience autorisée sur la parcelle.

2. Tester les seuils None/General/Moderate/Adult avec des expériences de maturités disponibles ; relever ce qui manque comme BLOQUÉ, pas PASS.

3. Ajouter l’UUID de votre propre expérience dans la liste de refus ; refaire l’attache puis T|@jump=n,version={R}.

4. Recommencer en laissant T imposer une règle avant l’identification tardive de l’expérience ; attendre le classement AttachmentResources.

5. Tester le contrôleur dans un enfant du linkset, le retrait de T, la désactivation globale et le rétablissement de la liste initiale.

**Résultat attendu :** Consentement d’expérience distinct de l’autorisation de contrôler RLVa. Seuil et liste bloquent les commandes/effets ; un refus identifié tard retire les règles de racine/enfants déjà acceptées et empêche les forces pendantes. Bloc retiré au détachement confirmé ; noms non résolus bornés à 5 minutes.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `jump`, `version`.

**Réglages couverts :** `temporary_controllers`, `experience_maturity`, `blocked_experiences`.

<a id="r01"></a>
## R01 — Dernière position de connexion

**Famille :** Reconnexion et reprise. **Préconditions :** Déconnexion/reconnexion réelle par l’humain, profil de test.

1. Envoyer :

   ```text
   /210001 A|lease 0
   ```

2. Envoyer :

   ```text
   /210001 A|boot @tploc=n
   ```

3. Choisir avant déconnexion un lieu de départ différent de la position actuelle ; quitter proprement et reconnecter.

4. Relever l’emplacement d’arrivée avant les replays boot annoncés.

5. Refaire assis avec unsit=n, puis sans tploc/unsit, et après désactivation globale de RLVa.

6. Arrêter boot, supprimer les locks et remettre lease 180.

**Résultat attendu :** Le verrou de prochaine connexion impose la dernière position selon les drapeaux natifs, y compris assise verrouillée ; désactivation l’annule. Les locks eux-mêmes ne sont pas persistés : les lignes boot rejouées à +3/+10 s sont des commandes de script nouvelles, à distinguer de l’arrivée initiale. Le cas initial par défaut est également à relever.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `tploc`, `unsit`.

<a id="r02"></a>
## R02 — Watchdog et passage de région

**Famille :** Reconnexion et reprise. **Préconditions :** Région voisine accessible ; événement de perte/reprise pour la sous-variante watchdog.

1. Verrouiller un accessoire d’inventaire ordinaire et passer une frontière de région avec lui.

2. Comparer les UUID d’item, point porté et links COF avant/après ; observer une perte/remplacement confirmé si le simulateur en produit.

3. Relever SaveAssetIntoInventory, délai de secours 15 s et nouvelle tentative après 30 s avec les traces disponibles.

4. Refaire sur un accessoire temporaire sans original d’inventaire.

5. Pendant une reprise pendante, désactiver RLVa et attendre plus de 30 s.

**Résultat attendu :** Objet ordinaire verrouillé restauré au point exact, après sauvegarde quand elle est observée ; reprises bornées et pas de boucle. Temporaire : aucune restauration d’inventaire inventée. Disable annule toutes les reprises pendantes. Si aucune perte serveur n’est produite, ne pas annoncer la variante reprise réussie sur la seule base d’un crossing sans incident.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `detach`, `remattach`.

<a id="r03"></a>
## R03 — Garbage collection d’un émetteur absent

**Famille :** Reconnexion et reprise. **Préconditions :** Objet jetable, lease 0, possibilité de supprimer/détacher sans @clear.

1. Désactiver boot et le timeout d’A : A|lease 0 ; imposer A|@fly=n.

2. Faire disparaître réellement A sans envoyer clear : par exemple supprimer un contrôleur rezzé possédé, puis attendre les sondes périodiques. Ne pas toucher A pour ce test car le toucher efface ses règles.

3. Relever les étapes de 30 s, jusqu’à vingt absences consécutives pour une attache disparue non confirmée ; comparer avec retrait explicitement confirmé.

4. Faire revenir un autre objet ou une copie portant le même nom ; vérifier qu’elle n’hérite pas de l’UUID absent.

5. Nettoyer via disable global et remettre lease 180 sur les exemplaires restants.

**Résultat attendu :** Nettoyage selon présence réelle et confirmations, jamais par simple homonymie. Source rezzée et attache connue peuvent avoir des chemins de retrait différents ; les vingt absences à 30 s justifient un test pouvant durer dix minutes.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `fly`.

<a id="r04"></a>
## R04 — Notifications de tenue et assise confirmées

**Famille :** Reconnexion et reprise. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@notify:210103=n
   ```

2. Changer une chemise, retirer puis ajouter un accessoire, s’asseoir puis se lever.

3. Refaire avant chargement complet de la tenue, lors d’une tenue remplacée et après reconnexion.

4. Interrompre une assise, refuser un port, puis refaire après confirmation ; comparer l’ordre des notifications.

5. Nettoyer et désactiver RLVa pendant une transition pendante.

**Résultat attendu :** Notifications associées aux changements confirmés ; retrait avant ajout pour vêtements/corps, pas de faux changements au chargement initial/incomplet ou lors d’une action échouée. Les acteurs et UUID de siège/tenue correspondent aux commandes acceptées.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `notify`, `sit`, `unsit`, `attach`.

<a id="r05"></a>
## R05 — Désactivation globale sous restrictions cumulées

**Famille :** Reconnexion et reprise. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@fly=n,jump=n,showinv=n,shownames=n,showloc=n,setcam=n,sendim=n,sendchat=n,detach=n,setsphere=n,setoverlay=n
   ```

2. Envoyer :

   ```text
   /210001 B|@unsit=n,remattach=n,setgroup=n
   ```

3. Créer aussi une attente de consentement IM, une offre partagée et une force nommée/maturité pendante quand possible.

4. Désactiver le système dans Préférences, sans clear des objets.

5. Vérifier mouvement, chat, IM, inventaire, caméra, rendu, confidentialité et liste des restrictions ; attendre les callbacks différés.

6. Réactiver sans rejouer les scripts ; vérifier qu’aucune règle ancienne ne revient. Arrêter ensuite tous les scripts boot et nettoyer les fixtures.

**Résultat attendu :** Libération complète des règles de session et annulation des travaux RLVa pendants ; les réponses déjà engagées ne recréent pas de workflow. Caméra/rendu reviennent aux réglages utilisateur concernés. Les forces ponctuelles déjà exécutées, comme un vrai déplacement, ne sont pas annulées par voyage inverse automatique.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `fly`, `jump`, `showinv`, `shownames`, `showloc`, `setcam`, `sendim`, `sendchat`, `detach`, `setsphere`, `setoverlay`, `unsit`, `remattach`, `setgroup`.

**Réglages couverts :** `rlva_enabled`.

<a id="e00"></a>
## E00 — Exclusivité et préférence NoSetEnv

**Famille :** Environnement. **Préconditions :** Compte principal, contrôleurs A et B.

1. Choisir un environnement de départ connu et noter sa sélection utilisateur.

2. Envoyer :

   ```text
   /210001 A|@setenv=n
   ```

3. Envoyer :

   ```text
   /210001 B|@setenv=n,setenv_cloudcoverage:0.8=force
   ```

4. Depuis les fenêtres natives, tenter un changement de ciel/eau/jour.

5. Envoyer :

   ```text
   /210001 A|@setenv_cloudcoverage:0.2=force
   ```

6. Désactiver l’autorisation des locks d’environnement, puis A|@setenv=y ; relever si le lock reste actif.

7. Envoyer :

   ```text
   /210001 A|clear
   ```

8. Envoyer :

   ```text
   /210001 B|clear
   ```

9. Tenter à nouveau setenv=n avec cette préférence off ; tester séparément une force de propriété puis la découverte de setenv.

10. Restaurer le réglage et l’environnement de départ.

**Résultat attendu :** Propriétaire exclusif et contrôles natifs respectés. NoSetEnv rejette add/rem des locks, pas la découverte ni les forces de propriétés ; clear et disable restent les sorties. Les overrides de session ne doivent pas remplacer une préférence sauvegardée.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setenv`, `getcommand`.

**Réglages couverts :** `allow_environment_locks`.

<a id="ep001"></a>
## EP001 — densitymultiplier

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_densitymultiplier={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_densitymultiplier:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_densitymultiplier={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_densitymultiplier`, `setenv_densitymultiplier`.

<a id="ep002"></a>
## EP002 — distancemultiplier

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_distancemultiplier={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_distancemultiplier:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_distancemultiplier={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_distancemultiplier`, `setenv_distancemultiplier`.

<a id="ep003"></a>
## EP003 — dropletradius

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_dropletradius={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_dropletradius:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_dropletradius={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_dropletradius`, `setenv_dropletradius`.

<a id="ep004"></a>
## EP004 — hazedensity

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_hazedensity={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_hazedensity:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_hazedensity={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_hazedensity`, `setenv_hazedensity`.

<a id="ep005"></a>
## EP005 — hazehorizon

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_hazehorizon={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_hazehorizon:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_hazehorizon={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_hazehorizon`, `setenv_hazehorizon`.

<a id="ep006"></a>
## EP006 — icelevel

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_icelevel={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_icelevel:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_icelevel={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_icelevel`, `setenv_icelevel`.

<a id="ep007"></a>
## EP007 — maxaltitude

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_maxaltitude={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_maxaltitude:1600=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_maxaltitude={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_maxaltitude`, `setenv_maxaltitude`.

<a id="ep008"></a>
## EP008 — moisturelevel

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_moisturelevel={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_moisturelevel:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_moisturelevel={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_moisturelevel`, `setenv_moisturelevel`.

<a id="ep009"></a>
## EP009 — scenegamma

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_scenegamma={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_scenegamma:1.2=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_scenegamma={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_scenegamma`, `setenv_scenegamma`.

<a id="ep010"></a>
## EP010 — cloudcoverage

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudcoverage={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudcoverage:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudcoverage={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudcoverage`, `setenv_cloudcoverage`.

<a id="ep011"></a>
## EP011 — cloudscale

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudscale={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudscale:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudscale={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudscale`, `setenv_cloudscale`.

<a id="ep012"></a>
## EP012 — cloudvariance

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudvariance={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudvariance:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudvariance={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudvariance`, `setenv_cloudvariance`.

<a id="ep013"></a>
## EP013 — moonbrightness

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_moonbrightness={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_moonbrightness:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_moonbrightness={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_moonbrightness`, `setenv_moonbrightness`.

<a id="ep014"></a>
## EP014 — moonscale

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_moonscale={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_moonscale:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_moonscale={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_moonscale`, `setenv_moonscale`.

<a id="ep015"></a>
## EP015 — sunglowsize

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunglowsize={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunglowsize:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunglowsize={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ. Contrôler également la remise à zéro de la composante verte du glow, selon la référence.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunglowsize`, `setenv_sunglowsize`.

<a id="ep016"></a>
## EP016 — sunglowfocus

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunglowfocus={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunglowfocus:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunglowfocus={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ. Contrôler également la remise à zéro de la composante verte du glow, selon la référence.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunglowfocus`, `setenv_sunglowfocus`.

<a id="ep017"></a>
## EP017 — sunscale

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunscale={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunscale:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunscale={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunscale`, `setenv_sunscale`.

<a id="ep018"></a>
## EP018 — starbrightness

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_starbrightness={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_starbrightness:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_starbrightness={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_starbrightness`, `setenv_starbrightness`.

<a id="ep019"></a>
## EP019 — sunazimuth

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunazimuth={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunazimuth:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunazimuth={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunazimuth`, `setenv_sunazimuth`.

<a id="ep020"></a>
## EP020 — sunelevation

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunelevation={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunelevation:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunelevation={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunelevation`, `setenv_sunelevation`.

<a id="ep021"></a>
## EP021 — moonazimuth

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_moonazimuth={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_moonazimuth:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_moonazimuth={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_moonazimuth`, `setenv_moonazimuth`.

<a id="ep022"></a>
## EP022 — moonelevation

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_moonelevation={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_moonelevation:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_moonelevation={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_moonelevation`, `setenv_moonelevation`.

<a id="ep023"></a>
## EP023 — eastangle

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_eastangle={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_eastangle:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_eastangle={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_eastangle`, `setenv_eastangle`.

<a id="ep024"></a>
## EP024 — sunmoonposition

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunmoonposition={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunmoonposition:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunmoonposition={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunmoonposition`, `setenv_sunmoonposition`.

<a id="ep025"></a>
## EP025 — ambient

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_ambient={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_ambient:0.2/0.3/0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_ambient={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_ambient`, `setenv_ambient`.

<a id="ep026"></a>
## EP026 — bluedensity

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluedensity={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluedensity:0.2/0.3/0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluedensity={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluedensity`, `setenv_bluedensity`.

<a id="ep027"></a>
## EP027 — bluehorizon

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizon={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluehorizon:0.2/0.3/0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizon={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluehorizon`, `setenv_bluehorizon`.

<a id="ep028"></a>
## EP028 — cloudcolor

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolor={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudcolor:0.2/0.3/0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolor={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudcolor`, `setenv_cloudcolor`.

<a id="ep029"></a>
## EP029 — clouddensity

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_clouddensity={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_clouddensity:0.2/0.3/0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_clouddensity={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_clouddensity`, `setenv_clouddensity`.

<a id="ep030"></a>
## EP030 — clouddetail

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_clouddetail={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_clouddetail:0.2/0.3/0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_clouddetail={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_clouddetail`, `setenv_clouddetail`.

<a id="ep031"></a>
## EP031 — sunlightcolor

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunlightcolor={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunlightcolor:0.2/0.3/0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunlightcolor={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunlightcolor`, `setenv_sunlightcolor`.

<a id="ep032"></a>
## EP032 — cloudtexture

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudtexture={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudtexture:{TEXTURE}=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudtexture={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudtexture`, `setenv_cloudtexture`.

<a id="ep033"></a>
## EP033 — moontexture

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_moontexture={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_moontexture:{TEXTURE}=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_moontexture={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_moontexture`, `setenv_moontexture`.

<a id="ep034"></a>
## EP034 — suntexture

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_suntexture={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_suntexture:{TEXTURE}=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_suntexture={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_suntexture`, `setenv_suntexture`.

<a id="ep035"></a>
## EP035 — cloudscroll

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudscroll={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudscroll:0.1/-0.2=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudscroll={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudscroll`, `setenv_cloudscroll`.

<a id="ep036"></a>
## EP036 — daytime

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_daytime={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_daytime:0.25=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_daytime={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter daytime rapporte l’état natif : 2 pour un ciel fixe, -1 pour un cycle de jour, et non simplement 0.25. Tester ensuite -1 et le retour à un cycle partagé connu. Le résultat dépend de l’environnement initial, à noter.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_daytime`, `setenv_daytime`.

<a id="ep037"></a>
## EP037 — ambientr

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_ambientr={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_ambientr:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_ambientr={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_ambientr`, `setenv_ambientr`.

<a id="ep038"></a>
## EP038 — ambientg

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_ambientg={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_ambientg:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_ambientg={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_ambientg`, `setenv_ambientg`.

<a id="ep039"></a>
## EP039 — ambientb

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_ambientb={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_ambientb:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_ambientb={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_ambientb`, `setenv_ambientb`.

<a id="ep040"></a>
## EP040 — ambientx

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_ambientx={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_ambientx:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_ambientx={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_ambientx`, `setenv_ambientx`.

<a id="ep041"></a>
## EP041 — ambienty

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_ambienty={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_ambienty:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_ambienty={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_ambienty`, `setenv_ambienty`.

<a id="ep042"></a>
## EP042 — ambientz

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_ambientz={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_ambientz:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_ambientz={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_ambientz`, `setenv_ambientz`.

<a id="ep043"></a>
## EP043 — ambienti

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_ambienti={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_ambienti:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_ambienti={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_ambienti`, `setenv_ambienti`.

<a id="ep044"></a>
## EP044 — bluedensityr

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityr={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluedensityr:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityr={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluedensityr`, `setenv_bluedensityr`.

<a id="ep045"></a>
## EP045 — bluedensityg

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityg={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluedensityg:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityg={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluedensityg`, `setenv_bluedensityg`.

<a id="ep046"></a>
## EP046 — bluedensityb

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityb={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluedensityb:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityb={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluedensityb`, `setenv_bluedensityb`.

<a id="ep047"></a>
## EP047 — bluedensityx

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityx={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluedensityx:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityx={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluedensityx`, `setenv_bluedensityx`.

<a id="ep048"></a>
## EP048 — bluedensityy

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityy={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluedensityy:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityy={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluedensityy`, `setenv_bluedensityy`.

<a id="ep049"></a>
## EP049 — bluedensityz

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityz={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluedensityz:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityz={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluedensityz`, `setenv_bluedensityz`.

<a id="ep050"></a>
## EP050 — bluedensityi

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityi={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluedensityi:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluedensityi={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluedensityi`, `setenv_bluedensityi`.

<a id="ep051"></a>
## EP051 — bluehorizonr

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizonr={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluehorizonr:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizonr={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluehorizonr`, `setenv_bluehorizonr`.

<a id="ep052"></a>
## EP052 — bluehorizong

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizong={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluehorizong:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizong={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluehorizong`, `setenv_bluehorizong`.

<a id="ep053"></a>
## EP053 — bluehorizonb

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizonb={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluehorizonb:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizonb={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluehorizonb`, `setenv_bluehorizonb`.

<a id="ep054"></a>
## EP054 — bluehorizonx

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizonx={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluehorizonx:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizonx={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluehorizonx`, `setenv_bluehorizonx`.

<a id="ep055"></a>
## EP055 — bluehorizony

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizony={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluehorizony:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizony={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluehorizony`, `setenv_bluehorizony`.

<a id="ep056"></a>
## EP056 — bluehorizonz

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizonz={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluehorizonz:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizonz={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluehorizonz`, `setenv_bluehorizonz`.

<a id="ep057"></a>
## EP057 — bluehorizoni

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizoni={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_bluehorizoni:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_bluehorizoni={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_bluehorizoni`, `setenv_bluehorizoni`.

<a id="ep058"></a>
## EP058 — cloudcolorr

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorr={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudcolorr:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorr={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudcolorr`, `setenv_cloudcolorr`.

<a id="ep059"></a>
## EP059 — cloudcolorg

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorg={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudcolorg:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorg={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudcolorg`, `setenv_cloudcolorg`.

<a id="ep060"></a>
## EP060 — cloudcolorb

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorb={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudcolorb:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorb={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudcolorb`, `setenv_cloudcolorb`.

<a id="ep061"></a>
## EP061 — cloudcolorx

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorx={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudcolorx:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorx={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudcolorx`, `setenv_cloudcolorx`.

<a id="ep062"></a>
## EP062 — cloudcolory

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolory={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudcolory:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolory={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudcolory`, `setenv_cloudcolory`.

<a id="ep063"></a>
## EP063 — cloudcolorz

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorz={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudcolorz:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolorz={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudcolorz`, `setenv_cloudcolorz`.

<a id="ep064"></a>
## EP064 — cloudcolori

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolori={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudcolori:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudcolori={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudcolori`, `setenv_cloudcolori`.

<a id="ep065"></a>
## EP065 — cloudr

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudr={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudr:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudr={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudr`, `setenv_cloudr`.

<a id="ep066"></a>
## EP066 — cloudg

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudg={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudg:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudg={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudg`, `setenv_cloudg`.

<a id="ep067"></a>
## EP067 — cloudb

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudb={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudb:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudb={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudb`, `setenv_cloudb`.

<a id="ep068"></a>
## EP068 — cloudx

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudx={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudx:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudx={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudx`, `setenv_cloudx`.

<a id="ep069"></a>
## EP069 — cloudy

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudy={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudy:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudy={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudy`, `setenv_cloudy`.

<a id="ep070"></a>
## EP070 — cloudz

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudz={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudz:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudz={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudz`, `setenv_cloudz`.

<a id="ep071"></a>
## EP071 — cloudi

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudi={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudi:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudi={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudi`, `setenv_cloudi`.

<a id="ep072"></a>
## EP072 — clouddetailr

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailr={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_clouddetailr:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailr={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_clouddetailr`, `setenv_clouddetailr`.

<a id="ep073"></a>
## EP073 — clouddetailg

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailg={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_clouddetailg:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailg={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_clouddetailg`, `setenv_clouddetailg`.

<a id="ep074"></a>
## EP074 — clouddetailb

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailb={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_clouddetailb:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailb={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_clouddetailb`, `setenv_clouddetailb`.

<a id="ep075"></a>
## EP075 — clouddetailx

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailx={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_clouddetailx:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailx={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_clouddetailx`, `setenv_clouddetailx`.

<a id="ep076"></a>
## EP076 — clouddetaily

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_clouddetaily={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_clouddetaily:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_clouddetaily={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_clouddetaily`, `setenv_clouddetaily`.

<a id="ep077"></a>
## EP077 — clouddetailz

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailz={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_clouddetailz:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_clouddetailz={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_clouddetailz`, `setenv_clouddetailz`.

<a id="ep078"></a>
## EP078 — clouddetaili

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_clouddetaili={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_clouddetaili:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_clouddetaili={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_clouddetaili`, `setenv_clouddetaili`.

<a id="ep079"></a>
## EP079 — sunmooncolorr

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorr={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunmooncolorr:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorr={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunmooncolorr`, `setenv_sunmooncolorr`.

<a id="ep080"></a>
## EP080 — sunmooncolorg

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorg={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunmooncolorg:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorg={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunmooncolorg`, `setenv_sunmooncolorg`.

<a id="ep081"></a>
## EP081 — sunmooncolorb

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorb={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunmooncolorb:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorb={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunmooncolorb`, `setenv_sunmooncolorb`.

<a id="ep082"></a>
## EP082 — sunmooncolorx

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorx={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunmooncolorx:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorx={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunmooncolorx`, `setenv_sunmooncolorx`.

<a id="ep083"></a>
## EP083 — sunmooncolory

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolory={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunmooncolory:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolory={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunmooncolory`, `setenv_sunmooncolory`.

<a id="ep084"></a>
## EP084 — sunmooncolorz

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorz={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunmooncolorz:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolorz={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunmooncolorz`, `setenv_sunmooncolorz`.

<a id="ep085"></a>
## EP085 — sunmooncolori

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolori={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_sunmooncolori:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_sunmooncolori={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_sunmooncolori`, `setenv_sunmooncolori`.

<a id="ep086"></a>
## EP086 — cloudscrollx

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudscrollx={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudscrollx:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudscrollx={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudscrollx`, `setenv_cloudscrollx`.

<a id="ep087"></a>
## EP087 — cloudscrolly

**Famille :** Propriétés d’environnement. **Préconditions :** Environnement initial connu ; TEXTURE configurée pour les propriétés d’asset.

1. Envoyer :

   ```text
   /210001 A|@getenv_cloudscrolly={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_cloudscrolly:0.4=force
   ```

3. Envoyer :

   ```text
   /210001 A|@getenv_cloudscrolly={R}
   ```

4. Capturer le même cadrage et noter la valeur initiale/finale ; refaire dans le Legacy Viewer après remise au même environnement.

5. Envoyer :

   ```text
   /210001 A|@setenv=y
   ```

**Résultat attendu :** Getter après setter cohérent avec les unités et conversions natives ; comparer aussi les autres composantes avant/après, pas seulement une variation visuelle. Tolérance numérique cohérente avec six décimales ; les angles utilisent leurs domaines périodiques natifs. Libérer restaure la sélection de départ.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `getenv_cloudscrolly`, `setenv_cloudscrolly`.

<a id="ea01"></a>
## EA01 — Sélection asset

**Famille :** Environnement. **Préconditions :** Asset de paramètres lisible et presets/cycle de bibliothèque disponibles.

1. Configurer ASSET avec votre asset UUID ou nom exact de bibliothèque approprié.

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_asset:{ASSET}=force
   ```

3. Attendre le chargement confirmé ; essayer un asset/nom absent puis désactiver RLVa avant un retour tardif.

4. Envoyer :

   ```text
   /210001 A|clear
   ```

**Résultat attendu :** La sélection valide est chargée dans l’override de session, pas sauvegardée comme choix personnel ; erreur/absence traitée sans état bloqué. Disable/clear empêche une réponse tardive de réinstaller l’override.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setenv_asset`.

<a id="ea02"></a>
## EA02 — Sélection preset

**Famille :** Environnement. **Préconditions :** Asset de paramètres lisible et presets/cycle de bibliothèque disponibles.

1. Configurer PRESET avec votre asset UUID ou nom exact de bibliothèque approprié.

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_preset:{PRESET}=force
   ```

3. Attendre le chargement confirmé ; essayer un asset/nom absent puis désactiver RLVa avant un retour tardif.

4. Envoyer :

   ```text
   /210001 A|clear
   ```

**Résultat attendu :** La sélection valide est chargée dans l’override de session, pas sauvegardée comme choix personnel ; erreur/absence traitée sans état bloqué. Disable/clear empêche une réponse tardive de réinstaller l’override.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setenv_preset`.

<a id="ea03"></a>
## EA03 — Sélection daycycle

**Famille :** Environnement. **Préconditions :** Asset de paramètres lisible et presets/cycle de bibliothèque disponibles.

1. Configurer DAYCYCLE avec votre asset UUID ou nom exact de bibliothèque approprié.

2. Envoyer :

   ```text
   /210001 A|@setenv=n,setenv_daycycle:{DAYCYCLE}=force
   ```

3. Attendre le chargement confirmé ; essayer un asset/nom absent puis désactiver RLVa avant un retour tardif.

4. Envoyer :

   ```text
   /210001 A|clear
   ```

**Résultat attendu :** La sélection valide est chargée dans l’override de session, pas sauvegardée comme choix personnel ; erreur/absence traitée sans état bloqué. Disable/clear empêche une réponse tardive de réinstaller l’override.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setenv_daycycle`.

<a id="e99"></a>
## E99 — Getters, valeurs pseudo et résolution réelle

**Famille :** Debug. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@getdebug_avatarsex={R}
   ```

2. Envoyer :

   ```text
   /210001 A|@getdebug_aspectratio={R}
   ```

3. Envoyer :

   ```text
   /210001 A|@getdebug_renderresolutiondivisor={R}
   ```

4. Envoyer :

   ```text
   /210001 A|@getdebug_windlightuseatmosshaders={R}
   ```

5. Envoyer :

   ```text
   /210001 A|@getdebug_restrainedloveforbidgivetorlv={R}
   ```

6. Envoyer :

   ```text
   /210001 A|@getdebug_restrainedlovenosetenv={R}
   ```

7. Pour true/false/1/0 : envoyer setdebug_avatarsex:VALEUR=force puis interroger le getter ; tester default/invalide séparément.

8. Envoyer :

   ```text
   /210001 A|@setdebug_renderresolutiondivisor:12=force
   ```

9. Envoyer :

   ```text
   /210001 A|@getdebug_renderresolutiondivisor={R}
   ```

10. Comparer scène 3D, UI/HUD/étiquettes et picks sur objets visibles ; essayer une capture sans UI.

11. Envoyer :

   ```text
   /210001 B|@setdebug=n
   ```

12. Envoyer :

   ```text
   /210001 A|@setdebug_renderresolutiondivisor:2=force
   ```

13. Envoyer :

   ```text
   /210001 B|clear
   ```

14. Envoyer :

   ```text
   /210001 A|@setdebug_renderresolutiondivisor:default=force
   ```

15. Désactiver globalement pour libérer aussi la pseudo-valeur de sexe.

**Résultat attendu :** Getters reflètent les capacités/options ; AvatarSex conserve le texte booléen accepté sans changer arbitrairement des paramètres d’avatar. default n’est pas un booléen. Le diviseur réduit réellement les cibles 3D ; UI/HUD/labels restent nets, picks correctement remappés. Les locks des autres émetteurs restent applicables ; default/disable libèrent l’override.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `setdebug`, `setdebug_avatarsex`, `setdebug_renderresolutiondivisor`, `getdebug_avatarsex`, `getdebug_aspectratio`, `getdebug_renderresolutiondivisor`, `getdebug_windlightuseatmosshaders`, `getdebug_restrainedloveforbidgivetorlv`, `getdebug_restrainedlovenosetenv`.

<a id="s01"></a>
## S01 — recvchat_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@recvchat_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@recvchat=n,recvchat:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@recvchat:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@recvchat:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvchat_sec`, `permissive`.

<a id="s02"></a>
## S02 — recvchatfrom_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@recvchatfrom_sec:{PEER}=n
   ```

2. Exécuter l’action correspondante de C03/I01/I02/I03 pour PEER et PEER2.

3. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

4. Refaire l’action puis supprimer la forme exacte _sec chez A.

**Résultat attendu :** Blocage spécifique sur PEER, pas PEER2 ; aucune exception implicite par changement de suffixe. Les comportements à option cible seule n’utilisent pas une règle générale vide fictive pour compter les émetteurs.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvchatfrom_sec`, `permissive`.

<a id="s03"></a>
## S03 — recvemote_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@recvemote_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@recvemote=n,recvemote:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@recvemote:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@recvemote:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvemote_sec`, `permissive`.

<a id="s04"></a>
## S04 — recvemotefrom_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@recvemotefrom_sec:{PEER}=n
   ```

2. Exécuter l’action correspondante de C03/I01/I02/I03 pour PEER et PEER2.

3. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

4. Refaire l’action puis supprimer la forme exacte _sec chez A.

**Résultat attendu :** Blocage spécifique sur PEER, pas PEER2 ; aucune exception implicite par changement de suffixe. Les comportements à option cible seule n’utilisent pas une règle générale vide fictive pour compter les émetteurs.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvemotefrom_sec`, `permissive`.

<a id="s05"></a>
## S05 — recvim_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@recvim_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@recvim=n,recvim:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@recvim:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@recvim:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvim_sec`, `permissive`.

<a id="s06"></a>
## S06 — recvimfrom_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@recvimfrom_sec:{PEER}=n
   ```

2. Exécuter l’action correspondante de C03/I01/I02/I03 pour PEER et PEER2.

3. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

4. Refaire l’action puis supprimer la forme exacte _sec chez A.

**Résultat attendu :** Blocage spécifique sur PEER, pas PEER2 ; aucune exception implicite par changement de suffixe. Les comportements à option cible seule n’utilisent pas une règle générale vide fictive pour compter les émetteurs.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `recvimfrom_sec`, `permissive`.

<a id="s07"></a>
## S07 — sendim_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@sendim_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@sendim=n,sendim:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@sendim:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@sendim:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sendim_sec`, `permissive`.

<a id="s08"></a>
## S08 — sendimto_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@sendimto_sec:{PEER}=n
   ```

2. Exécuter l’action correspondante de C03/I01/I02/I03 pour PEER et PEER2.

3. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

4. Refaire l’action puis supprimer la forme exacte _sec chez A.

**Résultat attendu :** Blocage spécifique sur PEER, pas PEER2 ; aucune exception implicite par changement de suffixe. Les comportements à option cible seule n’utilisent pas une règle générale vide fictive pour compter les émetteurs.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sendimto_sec`, `permissive`.

<a id="s09"></a>
## S09 — startim_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@startim_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@startim=n,startim:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@startim:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@startim:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `startim_sec`, `permissive`.

<a id="s10"></a>
## S10 — startimto_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@startimto_sec:{PEER}=n
   ```

2. Exécuter l’action correspondante de C03/I01/I02/I03 pour PEER et PEER2.

3. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

4. Refaire l’action puis supprimer la forme exacte _sec chez A.

**Résultat attendu :** Blocage spécifique sur PEER, pas PEER2 ; aucune exception implicite par changement de suffixe. Les comportements à option cible seule n’utilisent pas une règle générale vide fictive pour compter les émetteurs.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `startimto_sec`, `permissive`.

<a id="s11"></a>
## S11 — sendchannel_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@sendchannel_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@sendchannel=n,sendchannel:210101=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@sendchannel:210101=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@sendchannel:210101=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sendchannel_sec`, `permissive`.

<a id="s12"></a>
## S12 — sendchannel_except_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@sendchannel_except_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@sendchannel_except=n,sendchannel_except:210101=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@sendchannel_except:210101=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@sendchannel_except:210101=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `sendchannel_except_sec`, `permissive`.

<a id="s13"></a>
## S13 — share_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@share_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@share=n,share:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@share:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@share:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `share_sec`, `permissive`.

<a id="s14"></a>
## S14 — accepttp_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@accepttp_sec:{PEER}=n
   ```

2. Faire envoyer le type d’offre/demande correspondant par PEER, puis par PEER2 ; relever les acceptations.

3. Envoyer :

   ```text
   /210001 A|@accepttp_sec:{PEER}=y
   ```

4. Refaire ; tester ensuite la forme générale accepttp_sec=n, puis supprimer la même forme.

**Résultat attendu :** Exception auto-accept ciblée puis suppression correctes. La forme générale active l’acceptation automatique ; _sec ne doit pas être interprété comme une interdiction d’accepter. Les autres locks et la maturité restent applicables, comme dans T06.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `accepttp_sec`, `permissive`.

<a id="s15"></a>
## S15 — accepttprequest_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@accepttprequest_sec:{PEER}=n
   ```

2. Faire envoyer le type d’offre/demande correspondant par PEER, puis par PEER2 ; relever les acceptations.

3. Envoyer :

   ```text
   /210001 A|@accepttprequest_sec:{PEER}=y
   ```

4. Refaire ; tester ensuite la forme générale accepttprequest_sec=n, puis supprimer la même forme.

**Résultat attendu :** Exception auto-accept ciblée puis suppression correctes. La forme générale active l’acceptation automatique ; _sec ne doit pas être interprété comme une interdiction d’accepter. Les autres locks et la maturité restent applicables, comme dans T06.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `accepttprequest_sec`, `permissive`.

<a id="s16"></a>
## S16 — tplure_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@tplure_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@tplure=n,tplure:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@tplure:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@tplure:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `tplure_sec`, `permissive`.

<a id="s17"></a>
## S17 — tprequest_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@tprequest_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@tprequest=n,tprequest:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@tprequest:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@tprequest:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `tprequest_sec`, `permissive`.

<a id="s18"></a>
## S18 — shownametags_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@shownametags_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@shownametags=n,shownametags:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@shownametags:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@shownametags:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `shownametags_sec`, `permissive`.

<a id="s19"></a>
## S19 — shownames_sec

**Famille :** Exceptions sécurisées. **Préconditions :** Cas de base C/I/T/D correspondant préparé ; PEER/PEER2 ou canaux de sonde.

1. Envoyer :

   ```text
   /210001 A|@shownames_sec=n
   ```

2. Envoyer :

   ```text
   /210001 B|@shownames=n,shownames:{PEER}=n
   ```

3. Effectuer l’action correspondante du chapitre de base : observer l’accord incomplet.

4. Envoyer :

   ```text
   /210001 A|@shownames:{PEER}=n
   ```

5. Refaire l’action avec l’accord de l’émetteur sécurisé.

6. Envoyer :

   ```text
   /210001 B|@shownames:{PEER}=y
   ```

7. Refaire pour prouver qu’un émetteur normal n’exige pas de répéter cet accord.

8. Envoyer :

   ```text
   /210001 B|@permissive=n
   ```

9. Refaire puis remettre l’exception chez B. Pour les canaux, utiliser le toucher de nettoyage si le canal de contrôle est bloqué.

**Résultat attendu :** La décision utilise les accords des émetteurs sécurisés ; permissive=n étend l’accord à tous les émetteurs concernés. Pour sendchannel_except la décision est inversée : l’exception désigne un canal interdit. Pour startim, fermer réellement la session avant chaque tentative pour ne pas activer l’exemption de session ouverte.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `shownames_sec`, `permissive`.

<a id="s99"></a>
## S99 — permissive ne sécurise pas un comportement sans _sec

**Famille :** Exceptions sécurisées. **Préconditions :** Compte principal, contrôleurs A et B.

1. Envoyer :

   ```text
   /210001 A|@edit=n,edit:{OBJECT}=n,touchworld=n,touchworld:{OBJECT}=n
   ```

2. Envoyer :

   ```text
   /210001 B|@edit=n,touchworld=n,permissive=n
   ```

3. Essayer édition et toucher de l’objet cible ; comparer à un autre objet sans exception.

4. Supprimer l’exception chez A puis refaire ; nettoyer ensuite les deux émetteurs.

**Résultat attendu :** Les exceptions de comportements qui ne possèdent pas de variante _sec restent permissives, même sous permissive=n. Les deux objets constituent un contrôle positif/négatif.

**Nettoyage :** A|clear puis B|clear ; pour T/C/D/E/F/G/H, effacer aussi chaque émetteur utilisé. En cas de blocage, désactiver globalement RLVa, arrêter les sweeps/profils boot et réinitialiser les sondes avant réactivation.

**À consigner :** versions, valeurs initiales, chaque sous-variante, réponse/comportement Legacy, réponse/comportement Aurora, statut, preuve et restauration.

**Commandes couvertes :** `permissive`, `edit`, `touchworld`.
