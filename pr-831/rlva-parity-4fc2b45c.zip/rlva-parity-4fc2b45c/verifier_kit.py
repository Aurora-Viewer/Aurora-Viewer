"""Validate test-kit coverage/contracts, optionally source drift and LSL syntax.

Standard library only, Python 3.10+. Never connects to a grid or runs LSL.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import re
import subprocess
import sys
import struct
import zlib


def table(text, name):
    match = re.search(r'(?s)(?:pub )?const '+name+r': &\[&str\] = &\[(.*?)\];', text)
    if not match:
        raise ValueError('Missing source table '+name)
    return re.findall(r'"([^"]+)"', match.group(1))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, help='Optional Aurora checkout; compare the actual command tables and source hashes.')
    parser.add_argument('--lslint', type=Path, help='Optional local lslint executable; syntax analysis only, no grid execution.')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    data = json.loads((root/'tests.json').read_text(encoding='utf-8'))
    cases = data['cases']
    ids = [c['id'] for c in cases]
    assert len(ids) == len(set(ids)), 'Duplicate test IDs'
    commands = set(data['command_inventory'])
    prefs = set(data['preference_inventory'])
    covered = {n for c in cases for n in c['commands']}
    covered_prefs = {n for c in cases for n in c['preferences']}
    assert commands <= covered, f'Uncovered commands: {sorted(commands-covered)}'
    assert prefs <= covered_prefs, f'Uncovered preferences: {sorted(prefs-covered_prefs)}'
    supported_tokens = {'R','ME','SELF','REGION','LOCAL','GLOBAL','PEER','PEER2','OBJECT','SEAT','TEXTURE','GROUP','GROUPNAME','ROLE','ASSET','PRESET','DAYCYCLE','FOLDER','DESTINATION','BADREGION'}
    for case in cases:
        assert case['requires'] and case['expected'] and case['cleanup'] and case['steps'], case['id']
        for step in case['steps']:
            if re.match(r'^[A-Z]+\|',step):
                assert len(step.encode('utf-8')) <= 900, ('Oversized control command',case['id'])
                unknown = set(re.findall(r'\{([A-Z0-9_]+)\}',step))-supported_tokens
                assert not unknown, (case['id'], 'Unknown controller tokens',unknown)
    for card in (root/'notecards').glob('*.txt'):
        rows=[]
        for line in card.read_text(encoding='utf-8').splitlines():
            if not line or line.startswith('#'): continue
            id, command = line.split('|',1)
            assert re.match(r'^@(get|version|find)',command) and command.endswith('={R}'), (card.name,id,'Non-query')
            assert len(command.encode()) <= 900, (card.name,id,'Oversized query')
            rows.append(id)
        assert len(rows)==len(set(rows)) and len(rows)<1000, (card.name,'Invalid row inventory')
        assert len(card.read_text(encoding='utf-8').splitlines())<1000, (card.name,'Physical line limit')
    with (root/'RESULTATS.csv').open(encoding='utf-8-sig',newline='') as stream:
        rows=list(csv.DictReader(stream,delimiter=';'))
    assert [row['ID'] for row in rows]==ids, 'Result sheet inventory mismatch'
    with (root/'COUVERTURE.csv').open(encoding='utf-8-sig',newline='') as stream:
        rows=list(csv.DictReader(stream,delimiter=';'))
    assert {r['Nom'] for r in rows if r['Type']=='commande'}==commands, 'Command coverage CSV mismatch'
    assert {r['Nom'] for r in rows if r['Type']=='preference'}==prefs, 'Preference coverage CSV mismatch'
    if (root/'TESTS-COMPLETS.md').exists():
        guide=(root/'TESTS-COMPLETS.md').read_text(encoding='utf-8')
        assert re.findall(r'^## (\w+) — ',guide,re.M)==ids, 'Detailed guide inventory mismatch'
    if (root/'CHECKLIST.html').exists():
        page=(root/'CHECKLIST.html').read_text(encoding='utf-8')
        embedded=json.loads(re.search(r'const DATA=(.*);\nconst KEY=',page).group(1))
        assert embedded==data, 'Interactive checklist data mismatch'
        assert not re.search(r'<(?:script|link|img|iframe)\b[^>]*(?:src|href)=[\"\']https?://',page), 'Remote active content'
    for name,alphas in [('overlay-mask.png',{0,32,33,255}),('world-grid.png',{255})]:
        content=(root/'assets'/name).read_bytes()
        assert content[:8]==b'\x89PNG\r\n\x1a\n', name
        position=8; compressed=b''
        while position<len(content):
            length=struct.unpack('!I',content[position:position+4])[0]
            tag=content[position+4:position+8]; body=content[position+8:position+8+length]
            if tag==b'IHDR': assert struct.unpack('!IIBBBBB',body)==(512,256,8,6,0,0,0), name
            if tag==b'IDAT': compressed+=body
            position+=length+12
        raw=zlib.decompress(compressed)
        stride=512*4+1
        assert len(raw)==256*stride and all(raw[y*stride]==0 for y in range(256)), name
        assert {raw[y*stride+1+x*4+3] for y in range(256) for x in range(512)}==alphas,name
    catalogue=commands-{'clear'}
    filters=data['catalogue_filters']
    extra_names={n for item in data['catalogue_type_filters'] for n in item['names']}
    assert all(any(f in n for f in filters) or n in extra_names for n in catalogue), 'Catalogue filter gap'
    assert all(len('|'.join(sorted(n for n in catalogue if f in n)).encode())<=700 for f in filters), 'Catalogue reply overflow'
    if args.source:
        base=args.source/'crates/aurora-viewer/src/world'
        source=(base/'rlva.rs').read_text(encoding='utf-8')
        env=(base/'rlva/environment.rs').read_text(encoding='utf-8')
        effect=(base/'rlva/effects.rs').read_text(encoding='utf-8')
        pref=(base/'rlva/preferences.rs').read_text(encoding='utf-8')
        live=set(table(source,'RESTRICTIONS')+table(source,'FORCES')+table(source,'QUERIES')+table(effect,'MODIFIERS')+['clear'])
        strict=re.findall(r'"([^"]+)"',re.search(r'(?s)fn supports_strict\(.*?\n}',source).group())
        live.update(n+'_sec' for n in strict)
        properties=table(env,'SCALARS')+table(env,'COLORS')+table(env,'TEXTURES')+['cloudscroll','daytime']
        for name in table(env,'LEGACY'):
            properties.extend(name+s for s in (['x','y'] if name=='cloudscroll' else ['r','g','b','x','y','z','i']))
        live.update(p+n for p in ['getenv_','setenv_'] for n in properties)
        live.update(['setenv_asset','setenv_preset','setenv_daycycle'])
        live_prefs=set(re.findall(r'pub (\w+):',pref))|{'rlva_enabled'}
        assert live==commands, ('Source command drift', sorted(live-commands),sorted(commands-live))
        assert live_prefs==prefs, ('Source preference drift',live_prefs^prefs)
        for relative, expected in data['source_files'].items():
            assert hashlib.sha256((args.source/relative).read_bytes()).hexdigest()==expected, 'Source content drift: '+relative
    scripts=list((root/'scripts').glob('*.lsl'))
    if args.lslint:
        for script in scripts:
            result=subprocess.run([str(args.lslint),'-p',str(script)],capture_output=True,text=True,errors='replace')
            output=result.stdout+result.stderr
            assert result.returncode==0 and re.search(r'Errors:\s*0\s+Warnings:\s*0',output), (script.name,output)
    print(json.dumps(dict(artifact_checks='PASS',cases=len(cases),commands=len(commands),preferences=len(prefs),
                          scripts=len(scripts),source_checked=bool(args.source),lsl_syntax_checked=bool(args.lslint),
                          grid_tests='NOT RUN; artifact checks are not RLVa parity acceptance.'),ensure_ascii=False,indent=2))


if __name__=='__main__':
    try: main()
    except (AssertionError,ValueError,OSError,KeyError) as error:
        print('FAIL:',error,file=sys.stderr)
        raise SystemExit(1)
