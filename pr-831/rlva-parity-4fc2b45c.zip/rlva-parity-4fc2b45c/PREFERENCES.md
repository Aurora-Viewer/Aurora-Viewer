# Les 24 réglages à vérifier

Valeurs initiales du source Aurora de cette révision. Les options subordonnées sont inactives quand l’interrupteur global est désactivé. Pour comparer un état modifié, aligner les deux viewers et enregistrer la valeur dans les résultats.

| Réglage interne | Défaut | Fonction | Cas |
|---|---|---|---|
| `allow_environment_locks` | Activé | Accepte les locks setenv ; désactivé, les ajouts/retraits de lock sont ignorés, les forces restent distinctes. | E00 |
| `allow_ooc` | Activé | Conserve les formes OOC autorisées sous filtrage du chat. | C01 |
| `allow_shared_offers` | Activé | Classement des cadeaux consentis préfixés #RLV/~ dans l’inventaire partagé. | W12 |
| `auto_rename` | Activé | Ajoute le point au nom modifiable ou range le no-modify dans un dossier replié, lorsque nécessaire. | W11 |
| `blocked_experiences` | Liste native initiale non vide | UUID d’expériences toujours refusées ; valeur exacte dans le source des préférences. | G06 |
| `compatibility_list` | Vide | Contrôleurs portés par créateur/nom qui doivent recevoir l’ancien numéro de protocole. | P07 |
| `debug_commands` | Désactivé | Journal des commandes reçues et de leur traitement. | P08 |
| `debug_hide_unset_duplicate` | Désactivé | Masque les retours doublon/non-défini dans ce journal. | P08 |
| `experience_maturity` | Modéré (2) | Autorisation des contrôleurs temporaires issus d’expérience : aucun, général, modéré, adulte. | G06 |
| `experimental_commands` | Activé | Active le groupe natif de commandes expérimentales et leur découverte. | P08 |
| `hide_locked_attachments` | Désactivé | Masque la présence d’attaches verrouillées aux requêtes concernées, sans enlever les locks. | W09 |
| `hide_locked_layers` | Désactivé | Masque de même les vêtements verrouillés ; couches de corps traitées séparément. | W09 |
| `im_queries` | Activé | Réponses aux requêtes RLVa reçues en vrai IM. | I06, I07 |
| `im_queries_auto_share` | Désactivé | Partage automatique des listes demandées en IM, plutôt que consentement ponctuel. | I06 |
| `legacy_naming` | Activé | Règles historiques de résolution des noms/points dans les dossiers partagés. | W08 |
| `replace_unlocked` | Activé | Remplace les prédécesseurs libres en conservant les attaches verrouillées ; désactivé, refus strict sur point verrouillé. | W10 |
| `rlva_enabled` | Désactivé | Interrupteur global ; libère restrictions et travail différé à la désactivation. | P01, R05 |
| `shared_wear` | Activé | Permet le port partagé sans suffixe de point imposé au nom. | W08, W11 |
| `show_ellipsis` | Activé | Remplace le chat reçu filtré par des ellipses plutôt que le supprimer. | C03 |
| `show_redirect_typing` | Désactivé | Montre la saisie malgré une redirection du chat. | C06 |
| `split_redirect_chat` | Désactivé | Découpe les longues redirections au lieu d’une réponse unique bornée. | C04 |
| `temporary_controllers` | Activé | Accepte les commandes des attaches temporaires ordinaires ; leur désactivation ne clear pas rétroactivement les anciennes règles. | G05, G06 |
| `wear_add_prefix` | `+` | Préfixe qui transforme une opération de remplacement en ajout. | W08 |
| `wear_replace_prefix` | Vide | Préfixe qui transforme une opération d’ajout en remplacement ; vide désactive cet override. | W08 |
