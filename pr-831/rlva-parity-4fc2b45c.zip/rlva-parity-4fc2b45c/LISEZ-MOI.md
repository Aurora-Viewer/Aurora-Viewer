# Vérifier la parité fonctionnelle RLVa

Kit du **22 octobre 2026**, pour **Aurora `4fc2b45cb`**, branche `feat/rlva`.

Le plan contient **221 fiches**, couvre les **395 noms/variantes de commandes recensés dans cette branche** et ses **24 réglages, interrupteur global compris**. Il ne certifie pas encore la parité : **aucun résultat sur grille n'est prérempli**. Le catalogue du Legacy Viewer doit également être comparé : toute commande supplémentaire ou différence de comportement ouvre un écart à traiter. La référence est le fonctionnement de RLVa ; la disposition des fenêtres du Legacy Viewer n'est pas à reproduire.

## Fichiers à utiliser

| Fichier | Usage |
|---|---|
| [TESTS-COMPLETS.md](TESTS-COMPLETS.md) | Toutes les étapes, préconditions, résultats attendus et nettoyages des 221 cas |
| [CHECKLIST.html](CHECKLIST.html) | Même plan, recherche, filtres, saisie des résultats, export JSON/CSV ; ouvrir dans un navigateur |
| [RESULTATS.csv](RESULTATS.csv) | Feuille vierge à remplir dans Excel/LibreOffice ; séparateur `;`, UTF-8 |
| [COUVERTURE.csv](COUVERTURE.csv) | Chaque commande/réglage et les cas qui le couvrent |
| [PREFERENCES.md](PREFERENCES.md) | Sens, valeurs initiales et cas des 24 réglages |
| [scripts](scripts/) | Les huit scripts LSL à copier dans des objets de test |
| [notecards](notecards/) | Balayages de requêtes et de découverte des commandes |
| [assets](assets/) | Deux textures de test exactes, à importer manuellement si nécessaires |
| [verifier_kit.py](verifier_kit.py) | Vérification hors ligne du kit, de sa couverture, éventuellement du source et de la syntaxe LSL |
| [comparer_catalogues.py](comparer_catalogues.py) | Comparaison de deux listes de noms de commandes |
| [generer_partitions.py](generer_partitions.py) | Sous-partitions de découverte lorsqu'une réponse de catalogue est tronquée |
| [VERIFICATIONS.md](VERIFICATIONS.md) | Vérifications réellement effectuées sur les livrables, sans connexion à une grille |

Les fichiers CSV et la checklist sont deux supports indépendants : choisir son support principal. La checklist enregistre dans le stockage local du navigateur ; **exporter régulièrement**, car déplacer le fichier ou changer de navigateur peut changer ce stockage. Elle n'envoie rien sur Internet. Un export JSON peut être réimporté dans la même checklist. Les preuves/captures se conservent séparément, avec leur chemin dans les observations.

## 1. Préparer la comparaison

1. Noter la version exacte des deux viewers, leur langue et leurs réglages RLVa. Utiliser le même compte principal **successivement** dans les deux viewers, les mêmes objets conservés sur place, la même tenue de test et les mêmes réglages. L'UUID d'une attache peut changer au rez : relever l'UUID de chaque session. Ne pas comparer deux personnages avec des droits différents.
2. Prévoir un témoin consentant ; plusieurs cas IM/conférence nécessitent deux témoins, un groupe commun et des conversations réellement fermées. Les témoins utilisent un vrai viewer pour les vrais IM, appels, invitations d'amitié, offres/demandes de TP et messages de groupe. Un IM d'objet ne les remplace pas.
3. Choisir une parcelle où le rez et les scripts sont autorisés, des destinations de test autorisées et, pour les croisements, une région voisine. Prévoir des sièges à plusieurs distances, une cible modifiable, une copie no-modify, un HUD et un objet avec surface volumineuse pour le seuil de toucher. Si un droit manque, noter **BLOQUE**, jamais PASS par supposition.
4. Sauvegarder la tenue, la hauteur, le FOV, les presets caméra/environnement, le groupe/titre, les réponses automatiques, les préférences de saisie et d'inactivité. Utiliser des copies de vêtements/accessoires dont on accepte le remplacement. Les forces ponctuelles ne sont pas toutes annulées par `clear` : restaurer ces valeurs explicitement.
5. Réserver les tests d'expérience aux expériences que le testeur peut utiliser et à une parcelle autorisée. Tester les maturités et listes bloquées seulement si l'on dispose réellement des expériences concernées. Sinon, conserver les sous-cas BLOQUE.
6. Garder les identifiants de compte et mots de passe hors des scripts et fichiers du kit. Les UUID d'objets/témoins sont saisis manuellement dans la mémoire des sondes ; ils ne sont pas préremplis dans le kit.

**Connexion et essais sur grille : par l'humain.** Le kit n'automatise aucune connexion. Un profil neuf signifie un profil de test distinct, sans supprimer ou écraser les réglages habituels.

## 2. Construire les contrôleurs

1. Créer deux petits prims séparés appartenant au compte principal. Nommer le premier `RLVa Test A`, mettre **`A` dans sa description** ; nommer l'autre `RLVa Test B`, description **`B`**.
2. Dans chaque prim, créer un script, remplacer tout son texte par [controller.lsl](scripts/controller.lsl), compiler en Mono puis réinitialiser le script. Vérifier `READY source=...` dans le chat propriétaire et deux UUID distincts.
3. Deux scripts dans le même prim ne donnent pas deux émetteurs. Pour C/D, créer des prims/enfants distincts avec leur propre description et leur propre copie du contrôleur. Après changement de description, réinitialiser. Pour les sept sphères, préparer A à G.
4. Créer les notecards **`RLVa-Queries`**, **`RLVa-Catalogue`** et **`RLVa-Decouverte`** dans le contenu d'A : copier le texte des fichiers homonymes du dossier `notecards`, **sans `.txt` dans leur nom d'inventaire**. Ne pas ajouter de commandes de restriction dans ces notecards.
5. Porter A/B pour les tests de contrôleurs portés, de chemins relatifs et de compatibilité ; les garder rezzés pour les cas qui demandent expressément un objet rezzé. Un objet porté depuis `#RLV/RLVa Validation/Simple` est nécessaire aux forces relatives. Réattacher/reconfigurer A si un test le retire.
6. Créer les autres sondes selon le tableau ci-dessous. Les compiler dans le viewer reste nécessaire : l'analyse statique locale ne simule pas le serveur LSL.

| Script | Où / propriétaire | Utilisation |
|---|---|---|
| [controller.lsl](scripts/controller.lsl) | Principal ; prims A/B/C… distincts | Toutes les commandes, réponses, notifications, balayages, profil de reconnexion facultatif |
| [world-target.lsl](scripts/world-target.lsl) | Cible rezzée ; copie en HUD si nécessaire | Toucher, texte flottant, siège ; journalise les interactions. Configurer manuellement la vente si l'on teste Acheter |
| [permission-probe.lsl](scripts/permission-probe.lsl) | Rezzé, ni porté ni siège occupé ; copies principal et témoin | `/210003 controls`, `attach`, `animation`, `teleport`, `combined`, `release` ; `/210003 target UUID`. Le destinataire touche pour demander ; aucune action n'est exécutée après permission |
| [temporary-attachment.lsl](scripts/temporary-attachment.lsl) | Prim rezzé transférable appartenant au principal, contrôleur T dans le même prim | Toucher propriétaire : demande d'attache puis attache temporaire poitrine après accord ; pas d'expérience |
| [experience-attachment.lsl](scripts/experience-attachment.lsl) | Autre prim T ; compiler avec son expérience autorisée | Toucher propriétaire : demande de permission d'expérience puis attache temporaire ; utiliser ce script à la place du précédent |
| [gift-giver.lsl](scripts/gift-giver.lsl) | Témoin ; contenu non-script copy+transfer | `/210004 target UUID`, `/210004 folder NOM` ; toucher par propriétaire = une offre. Défaut `#RLV/~RLVa Validation/Gift` |
| [object-channel-probe.lsl](scripts/object-channel-probe.lsl) | Témoin | `/210005 target UUID`, puis `say TEXTE`, `emote TEXTE`, `whisper TEXTE`, `shout TEXTE`, `direct TEXTE`, `im TEXTE` : messages **d'objet** |
| [caution-probe.lsl](scripts/caution-probe.lsl) | Objet isolé du principal | Toucher volontaire : demande DEBIT pour vérifier que RLVa n'accepte pas une permission sensible. **Refuser la question**. Aucune fonction de transfert d'argent ; une permission accordée accidentellement est immédiatement révoquée |

Pour les permissions appartenant au témoin, le témoin configure `target UUID_DU_PRINCIPAL`, puis le principal touche. Ne pas tester les auto-acceptations sur une attache ou sur un siège occupé : le simulateur peut déjà accorder certaines permissions dans ces situations. Révoquer/réinitialiser entre variantes.

La cible présente un prix de paiement de 1 pour observer le parcours Pay ; seul un humain décide de valider un paiement ou un achat. Le test du refus sous restriction peut se faire jusqu'au refus, sans transaction autorisée. Pour confirmer un paiement/achat réussi après libération, prévoir une transaction consentie et noter son résultat réel ; sinon sous-cas BLOQUE. Aucune sonde ne rembourse ni ne débite automatiquement.

## 3. Syntaxe et paramètres

Dans les fiches, une ligne `A|...` signifie : saisir **`/210001 A|...`** dans le chat de l'avatar principal. Chaque ligne est une commande distincte. Ne pas coller le paragraphe d'explications ni plusieurs lignes comme une seule commande.

```text
/210001 A|info
/210001 A|@version={R}
/210001 A|@fly=n
/210001 B|@fly=n
/210001 A|@fly=y
/210001 ALL|clear
```

`@fly=y` enlève seulement la restriction de cet émetteur. `A|@clear` est une commande RLVa ; `A|clear` est l'arrêt local de la sonde : clear RLVa, arrêt des balayages et du profil boot de ce prim. `ALL|clear` agit sur toutes les sondes présentes qui peuvent recevoir le canal.

Les jetons **avec accolades** sont remplacés par le contrôleur :

| Automatiques | Valeur |
|---|---|
| `{R}` | Canal de réponse de cette sonde : A=210011, B=210012… |
| `{ME}`, `{SELF}` | UUID du propriétaire / du prim émetteur |
| `{REGION}` | Région courante du prim |
| `{LOCAL}`, `{GLOBAL}` | Position locale de l'avatar / coordonnées globales, forme `x/y/z` |

Régler les variables nécessaires au cas, sans écrire les accolades dans la commande `set` :

```text
/210001 ALL|set PEER=UUID_DU_TEMOIN
/210001 ALL|set PEER2=UUID_DU_SECOND_TEMOIN
/210001 ALL|set OBJECT=UUID_DE_LA_CIBLE
/210001 ALL|set SEAT=UUID_RACINE_DU_SIEGE
/210001 ALL|set TEXTURE=UUID_ASSET_DE_LA_TEXTURE
/210001 ALL|set GROUP=UUID_DU_GROUPE
/210001 ALL|set GROUPNAME=NOM_EXACT_DU_GROUPE
/210001 ALL|set ROLE=PREFIXE_DU_ROLE
/210001 ALL|set ASSET=UUID_ASSET_ENVIRONNEMENT
/210001 ALL|set PRESET=NOM_DU_PRESET_DE_CIEL
/210001 ALL|set DAYCYCLE=NOM_DU_PRESET_DE_CYCLE
/210001 ALL|set FOLDER=RLVa Validation/Simple
/210001 ALL|set DESTINATION=COORDONNEES_GLOBALES_X/Y/Z
/210001 ALL|set BADREGION=NOM_DE_REGION_INEXISTANTE_POUR_CE_TEST
```

Ces noms `UUID_...` sont des **indications à remplacer**, pas des valeurs de test valides. Texture/environnement : employer l'UUID **d'asset**, pas celui de l'item d'inventaire. Pour une destination nommée, utiliser `Région/x/y/z` quand le cas le demande. Les variables non utilisées peuvent rester non configurées ; une commande contenant encore `{...}` est refusée. `ALL` configure seulement les sondes présentes : refaire après rez, reset ou changement d'instance.

Le canal 210103 observe `notify`; 210101 et 210102 observent les redirections. Les balayages utilisent 220000 et suivants, un canal par ligne et par lettre d'émetteur. Réserver ces canaux à ce kit. Si plusieurs kits tournent en parallèle à proximité, changer toute la plage de manière cohérente.

## 4. Arrêt et durée de vie

Par défaut, chaque contrôleur efface ses restrictions **180 secondes après sa dernière émission**, y compris après une requête. Toute expiration rend le test en cours invalide : recommencer, ne pas conclure à une libération correcte. Le toucher propriétaire d'un contrôleur efface uniquement ce prim.

Pour un essai de plus de trois minutes :

```text
/210001 A|lease 0
```

Puis à la fin :

```text
/210001 A|clear
/210001 A|lease 180
```

Si toucher/chat est bloqué : **Préférences > Protections > désactiver RLVa**, puis `ALL|clear` pendant qu'il est désactivé. Arrêter les profils, puis réinitialiser les sondes avant de réactiver. Le kit n'exempte pas son canal : `sendchannel=n` peut réellement bloquer `/210001`. Un clear seul peut aussi être ignoré pour une source temporaire dont l'option d'autorisation vient d'être coupée ; utiliser le commutateur global.

Le profil de rejeu est **facultatif**, en mémoire LSL :

```text
/210001 A|lease 0
/210001 A|boot @tploc=n
```

Il émet immédiatement, puis après attachement, rez ou changement de région à +3 et +10 secondes. Arrêter avec `A|boot off` puis `A|clear`. **Ne pas activer boot pendant un test censé prouver l'absence de persistance des locks** : un script qui les renvoie est une nouvelle émission. Le kit n'efface volontairement pas les règles lors d'un detach, afin de permettre le test de nettoyage des émetteurs disparus.

## 5. Construire l'inventaire FIXTURES

Créer manuellement la racine `#RLV`. Les chemins des commandes sont **relatifs à cette racine**, donc `RLVa Validation/Simple`, sans `#RLV/` dans l'option. Ne mettre dans cette zone que des copies de test.

```text
#RLV/
  RLVa Validation/
    Simple/
      Bracelet (chest)           [objet modifiable copié]
      Helmet (skull)             [objet no-modify copié]
      Shirt                     [copie de vêtement shirt]
      Gesture                   [geste de test]
      A                         [contrôleur copié, pour les cas relatifs]
    Nested/
      Direct (chest)
      child/
        Descendant (skull)
    Locked/
      Direct (chest)
      child/
        Descendant (skull)
    .(chest)/
      Folded object
      child/
        Must not be recursively collected
    Hidden/
      Visible object (chest)
    .Hidden/
      Hidden object (chest)
    FolderLink                  [lien de dossier vers Nested]
    HiddenLink                  [lien de dossier vers .Hidden]
    +Add/
      Add object (chest)
    Replace/
      Replace object (chest)
    Deep/
      deep match/
        First (chest)
        deeper/
          deep match/
            Second (skull)
    Nostrip/
      protected nostrip (chest)
      unprotected NOSTRIP (chest)
      Link nostrip              [lien vers un original sans ce mot]
      parent nostrip/
        Parent-protected (chest)
      .(chest) nostrip/
        Folded-protected
      ordinary nostrip/
        ordinary/
          Distant-parent (chest)
    .                           [nom littéral d'un enfant, pas un chemin relatif]
    ..                          [idem]
```

Préparer aussi un objet sans suffixe de point, un vêtement `pants`, les couches de corps dans une tenue de test complète, un lien vers un original hors `#RLV`, un nom contenant `/` et des liens COF multiples pour les requêtes de chemin. Conserver deux accessoires pouvant partager le même point. Pour le no-modify et le renommage automatique, garder l'original dans un dossier partagé distinct et observer la création du dossier replié. Les dossiers `Hidden` et `.Hidden` sont distincts ; seul le second commence par un point.

Les tests de retrait de corps se comparent à la référence avec une tenue valide ; ne pas supposer qu'une commande peut enlever une couche système obligatoire. LSL ne peut pas fabriquer l'arborescence d'inventaire d'un avatar, les couches de vêtement, des permissions no-modify ni les adhésions/rôles de groupe : leur préparation reste manuelle.

Pour les cadeaux, utiliser la sonde du témoin avec un contenu copy+transfer. La syntaxe de classement contient `#RLV/~` et accepte au plus quatre composants, racine comprise. Tester le refus, l'acceptation et l'option coupée, avec des offres réellement distinctes.

## 6. Exécuter les cas et enregistrer les preuves

1. Faire P01–P09, puis suivre les familles de [TESTS-COMPLETS.md](TESTS-COMPLETS.md). Les cas longs d'inactivité, de récupération et d'expériences peuvent être réservés à des sessions séparées. Les `WFxx` testent séparément **chaque orthographe de force d'inventaire** ; les `EPxxx`, chaque propriété environnement ; les `Sxx`, chaque variante sécurisée.
2. Avant **chaque cas et chaque variante indépendante**, nettoyer tous les émetteurs, vérifier le statut, remettre tenue/préférences/positions dans l'état initial indiqué. Activer RLVa pour les cas qui l'exigent. Les options expérimentales restent actives sauf pendant leur test. Pendant un test multi-émetteur, conserver les règles entre ses étapes, comme demandé.
3. Exécuter d'abord dans le Legacy Viewer, capturer le comportement réel et les réponses, nettoyer, puis refaire dans Aurora avec le même état initial. Une opération terminée doit être confirmée : position réelle, avatar effectivement assis, item arrivé, COF confirmé, message reçu par le témoin. Un bouton grisé ou un journal `SEND` ne prouve pas le résultat.
4. Conserver pour chaque sous-variante les commandes exactes, UUID d'émetteur, réponse/canal, position/rayon, préférences, captures et heure relative. Plusieurs variantes dans une fiche impliquent plusieurs lignes dans les observations ou un fichier de preuve lié. **Pas de PASS global si une sous-variante n'a pas été exécutée.**
5. Répéter l'ajout `n`, la suppression `y`, les doublons, `clear`, les combinaisons A/B, puis la désactivation globale là où la fiche le demande. En cas d'écart, refaire le plus petit scénario reproductible avec les mêmes paramètres et noter les deux résultats, sans corriger le viewer pendant la comparaison de référence.

| État | Sens |
|---|---|
| NON TESTE | Aucun essai réalisé pour cette variante |
| PASS | Les variantes exécutées satisfont l'attendu et la comparaison, preuve conservée |
| FAIL | Résultat Aurora incorrect ou régression manifeste par rapport à l'attendu |
| BLOQUE | Impossible à exécuter : droit, expérience, témoin, livraison différée ou condition nécessaire indisponible |
| DIFF | Différence confirmée avec la référence, même si elle est déjà documentée ou paraît souhaitable |

### Balayages et longues réponses

```text
/210001 A|sweep RLVa-Queries
```

Attendre `Sweep finished` avant le catalogue :

```text
/210001 A|sweep RLVa-Catalogue
```

Une seule requête à la fois, attente maximale huit secondes, canal distinct par ligne. `REPLIED` indique une réception, **pas une valeur correcte**. `EMPTY=[]` est une réponse vide ; `TIMEOUT` signifie qu'on n'a pas reçu de réponse. Une réponse lente peut exiger un essai manuel à part ; elle n'autorise pas à marquer PASS. Après `A|stop`, attendre au moins dix secondes avant de recommencer un balayage pour éviter de réutiliser un canal encore concerné par une ancienne réponse.

Le contrôleur imprime `DATA` en fragments et `B64` pour conserver le texte exact. Pour reconstruire une réponse longue : concaténer seulement les valeurs B64 de **la même requête/canal**, dans l'ordre des fragments, sans en-tête, puis décoder en UTF-8. Ne pas confondre plusieurs requêtes.

Le catalogue global `getcommand` peut dépasser la limite de réponse ; la notecard découpe les recherches par sous-chaînes, et demande séparément `setenv` avec le type `add`. Fusionner les noms de toutes les réponses **complètes** et dédupliquer. Si une partition du Legacy Viewer atteint la limite de paquet ou paraît coupée au milieu d'un nom, affiner cette partition dans la notecard et refaire les deux viewers. La taille prédite par le kit ne borne que le catalogue connu d'Aurora, pas une future version de référence.

Pour rechercher aussi les commandes dont le préfixe est absent d'Aurora :

```text
/210001 A|sweep RLVa-Decouverte
```

Ce balayage large comporte **988 requêtes**, donc environ 17 minutes si chaque réponse arrive rapidement, davantage en cas de délais. Il couvre les lettres initiales et toutes les paires lettre + lettre/chiffre/underscore. Plusieurs recherches sont redondantes, car le filtre natif est une sous-chaîne. **Une réponse tronquée de ce balayage impose d'affiner la partition**, même si le petit catalogue Aurora a déjà été obtenu. Le balayage ne fait aucune modification de restriction.

Par exemple, si `se` est tronqué :

```powershell
python "G:\_AURORA\validation\rlva-parity-4fc2b45c\generer_partitions.py" --filter se --type any --out ".\RLVa-Discovery-se.txt"
```

Copier le fichier produit dans une nouvelle notecard `RLVa-Discovery-se`, la placer dans A puis exécuter `A|sweep RLVa-Discovery-se`. Refaire récursivement pour chaque sous-partition encore tronquée. Garder aussi les noms exacts égaux au filtre parent, qui n'ont aucun caractère suivant ; les rechercher séparément par type `add`, `force`, `reply` si nécessaire, comme `setenv;add` dans le petit catalogue. La conclusion exige des partitions complètes et l'union de leurs réponses, pas seulement un balayage terminé sans timeout.

Créer `LegacyCommands.txt` et `AuroraCommands.txt` contenant **uniquement les noms de commandes**, séparés par lignes, `|`, `;` ou `,` : aucun timestamp, aucun préfixe de chat, aucune ligne vide servant de résultat.

```powershell
python "G:\_AURORA\validation\rlva-parity-4fc2b45c\comparer_catalogues.py" --legacy ".\LegacyCommands.txt" --aurora ".\AuroraCommands.txt"
```

Une liste identique ne prouve que l'égalité des noms annoncés ; il faut encore les cas comportementaux. Une commande supplémentaire dans la référence doit recevoir un cas et une conclusion explicite avant de déclarer une couverture intégrale.

### Textures

Importer manuellement [overlay-mask.png](assets/overlay-mask.png), conserver son alpha et configurer TEXTURE avec l'asset résultant. Quatre bandes verticales de gauche à droite : alpha **0, 32, 33, 255** ; 128 pixels chacune sur 512 × 256. Tester loin des frontières de bande pour le seuil de toucher, avec une texture effectivement chargée. [world-grid.png](assets/world-grid.png) donne un damier opaque de 16 pixels pour comparer textures forcées, flou et pixellisation. Adapter les mêmes textures/cadrages dans les deux viewers. Aucune texture n'a été téléversée par le générateur du kit.

### Cas non simulables par ces scripts

Les messages avatar/groupe/conférence et du personnel sont de vrais événements de leur origine, jamais un objet renommé pour l'occasion. Ne solliciter aucun membre du personnel pour obtenir un test : sans message approprié déjà disponible, laisser cette sous-variante BLOQUE. Les courses de métadonnées, réponses très tardives et arrivées avant/après un seuil ne sont validées sur grille que si la condition a été effectivement obtenue. Leur couverture interne existe, mais ne remplace pas une preuve de grille. Les octets de paquets et UUID de session se vérifient par les tests internes, pas par une simple copie du chat.

## 7. Différences connues à consigner

Ces points interdisent de transformer tous les résultats en PASS automatiquement :

- **RLVa désactivé par défaut dans Aurora**, choix explicitement demandé pour ce projet ; noter ce choix produit dans P01.
- **Option expérimentale appliquée immédiatement dans Aurora**, alors que la référence peut exiger un redémarrage. Comparer aussi les deux viewers après redémarrage dans le même état.
- **Groupe HUD des requêtes de points** : Aurora utilise le véritable attribut HUD des points actuels ; l'ancienne correspondance numérique du Legacy Viewer peut confondre des points Bento du corps avec le groupe HUD. Relever DIFF si constaté dans W02.
- **Flou gaussien variable** : noyau borné à un rayon maximal de 256 pixels dans Aurora ; pour des paramètres extrêmes la comparaison peut diverger. Relever explicitement le cas V06 et les paramètres, sans l'exclure silencieusement.

## 8. Vérifications hors ligne facultatives

Vérifier les fichiers du kit, sans installation de bibliothèque Python ni connexion :

```powershell
python "G:\_AURORA\validation\rlva-parity-4fc2b45c\verifier_kit.py"
```

Comparer aussi au checkout et analyser les scripts avec le linter local disponible :

```powershell
python "G:\_AURORA\validation\rlva-parity-4fc2b45c\verifier_kit.py" --source "G:\_AURORA\work\rlva" --lslint "G:\_AURORA\validation\water-effects-pr628\lslint-bin\extracted\lslint.exe"
```

Le linter n'est pas redistribué dans ce kit. Sans cet exécutable, omettre `--lslint` et compiler les sondes dans le viewer. Un changement des fichiers RLVa après la révision du kit produit un échec de comparaison des empreintes : réviser le plan pour cette nouvelle version, ne pas supprimer le contrôle pour annoncer PASS.

Les contrôles Rust complets du viewer sont lancés depuis son worktree :

```powershell
Set-Location "G:\_AURORA\work\rlva"
.\scripts\check.ps1
```

Ce script respecte les slots de compilation partagés et exécute syntaxe PowerShell, formatage, Clippy puis tests de tout le workspace. À cette révision, la dernière exécution enregistrée dans `docs/RLVA.md` compte **4 415 réussites, zéro échec, 27 ignorés**, dont **121 tests RLVa**. Ce bilan préexistant n'est pas une nouvelle exécution pendant la préparation de ce kit.

Pour rejouer uniquement les tests RLVa, puis le test Vulkan normalement ignoré, en respectant les mêmes slots :

```powershell
Set-Location "G:\_AURORA\work\rlva"
. .\scripts\common.ps1
Sync-BuildCache
$rlvaSlot = Enter-BuildSlot
try {
    cargo test --workspace rlva --locked
    if ($LASTEXITCODE -ne 0) { throw "RLVa tests failed" }
    cargo test --workspace rlva_gpu --locked -- --ignored
    if ($LASTEXITCODE -ne 0) { throw "RLVa GPU tests failed" }
} finally {
    Exit-BuildSlot $rlvaSlot
}
```

Le test Vulkan nécessite un GPU/pilote Vulkan approprié. Un test ignoré ou indisponible reste ainsi noté, il n'est pas converti en réussite. La démo hors ligne permet d'inspecter les outils/préférences mais ne simule pas toutes les confirmations serveur du présent plan.

## 9. Clôturer une session et décider de la parité

1. Désactiver globalement RLVa, envoyer `ALL|clear`, arrêter les profils boot/balayages, réinitialiser les scripts de test et retirer les attaches temporaires. Révoquer les permissions des sondes. Aucun script de test ne doit continuer à réémettre lors de la prochaine connexion.
2. Restaurer tenue, hauteur, caméra/FOV, environnement, groupe/titre, réponses automatiques, réglages d'inactivité et tous les réglages modifiés. Vérifier vol, saut, assise, chat, IM et inventaire libres. Conserver les copies de test si l'on doit reprendre, sans modifier les originaux habituels.
3. Exporter le journal de résultats et relier les preuves. Conserver la version des viewers et la révision du kit avec ce journal.
4. La conclusion de parité fonctionnelle exige : catalogue comparé sans manque non expliqué, tous les cas et sous-cas pertinents exécutés, aucun FAIL/DIFF non résolu, et une conclusion explicite pour chaque BLOQUE/NON TESTE. Un compteur de tests internes vert ne suffit pas. Les choix produit explicitement acceptés doivent être nommés comme tels, pas effacer les différences observées.

## Références

- Dans le checkout de cette révision : `docs/RLVA.md`, `crates/aurora-viewer/src/world/rlva.rs`, `rlva/preferences.rs`, `rlva/environment.rs`, `rlva/effects.rs`. Les empreintes de ces quatre fichiers sont dans `tests.json`.
- Documentation LSL primaire : [permissions d'experience](https://wiki.secondlife.com/wiki/LlRequestExperiencePermissions), [attache temporaire](https://wiki.secondlife.com/wiki/LlAttachToAvatarTemp), [permissions runtime](https://wiki.secondlife.com/wiki/Run_time_permissions), [OwnerSay](https://wiki.secondlife.com/wiki/LlOwnerSay).
- Le source du Legacy Viewer local sert à établir les attendus ; la version binaire réellement testée et ses résultats restent la preuve de comparaison.
