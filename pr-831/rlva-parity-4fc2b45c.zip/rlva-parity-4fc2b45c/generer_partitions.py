"""Write read-only getcommand subpartitions when a discovery reply is truncated.

Does not connect to a grid. Inspect the parent reply too: a command whose entire
name equals the parent filter has no following character. Keep it in the union.
"""
import argparse
from pathlib import Path
import re
import string

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--filter',required=True)
    parser.add_argument('--type',choices=['any','add','force','reply'],default='any')
    parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args()
    if not re.fullmatch(r'[a-z][a-z0-9_]*',args.filter):
        parser.error('Use a lowercase command substring only.')
    if args.out.exists():
        parser.error('Output exists; choose a new file to preserve previous results.')
    rows=['# Refine again if any reply is truncated. Retain exact parent-name matches.']
    for i,letter in enumerate(string.ascii_lowercase+string.digits+'_',1):
        rows.append(f'PART{i:03}|@getcommand:{args.filter+letter};{args.type};|={{R}}')
    args.out.write_text('\n'.join(rows)+'\n',encoding='utf-8')
    print(f'Wrote 37 read-only rows: {args.out}. Copy to a new notecard and sweep it.')
