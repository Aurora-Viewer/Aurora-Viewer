// Caution-dialog test only. Owner touch explicitly requests a debit permission
// question. Decline the dialog: it must never be auto-accepted by acceptpermission.
// There is no money-transfer function. Any unexpected grant is immediately revoked.
default
{
    touch_start(integer count)
    {
        if (llDetectedKey(0) == llGetOwner()) llRequestPermissions(llGetOwner(), PERMISSION_DEBIT);
    }
    run_time_permissions(integer granted)
    {
        llOwnerSay("[CAUTION] RESULT=" + (string)granted + "; any permission is now revoked.");
        if (granted) llRequestPermissions(llGetOwner(), 0);
    }
}
