// Use instead of temporary-attachment.lsl; compile this script into your own
// test experience, allowed on the test parcel. Also add controller.lsl, slot T.
default
{
    state_entry() { llOwnerSay("[EXPERIENCE TEMP] Touch to request your test experience's permissions."); }
    changed(integer change) { if (change & CHANGED_OWNER) llResetScript(); }
    touch_start(integer count)
    {
        if (llDetectedKey(0) == llGetOwner() && !llGetAttached())
            llRequestExperiencePermissions(llDetectedKey(0), "");
    }
    experience_permissions(key avatar) { llAttachToAvatarTemp(ATTACH_CHEST); }
    experience_permissions_denied(key avatar, integer reason) { llOwnerSay("[EXPERIENCE TEMP] Denied, reason=" + (string)reason); }
    attach(key avatar) { llOwnerSay("[EXPERIENCE TEMP] ATTACHED=" + (string)llGetAttached() + " source=" + (string)llGetKey()); }
}
