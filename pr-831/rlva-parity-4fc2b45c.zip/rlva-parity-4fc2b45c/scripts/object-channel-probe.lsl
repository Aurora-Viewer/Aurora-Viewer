// Owned by the consenting peer for non-owned object chat tests.
// This creates object chat/IM only. Avatar IM tests require the peer's viewer.
key target;
default
{
    state_entry() { llListen(210005, "", llGetOwner(), ""); llOwnerSay("[CHAT PROBE] /210005 target UUID ; then say/emote/whisper/shout/direct/im TEXT."); }
    changed(integer change) { if (change & CHANGED_OWNER) llResetScript(); }
    listen(integer channel, string name, key id, string message)
    {
        integer separator = llSubStringIndex(message, " ");
        if (separator == -1) return;
        string mode = llGetSubString(message, 0, separator - 1);
        string text = llGetSubString(message, separator + 1, -1);
        if (mode == "target") target = (key)text;
        else if (mode == "say") llSay(0, text);
        else if (mode == "emote") llSay(0, "/me " + text);
        else if (mode == "whisper") llWhisper(0, text);
        else if (mode == "shout") llShout(0, text);
        else if (target != NULL_KEY && mode == "direct") llRegionSayTo(target, 0, text);
        else if (target != NULL_KEY && mode == "im") llInstantMessage(target, text);
        else llOwnerSay("[CHAT PROBE] Unknown operation or missing target.");
    }
}
