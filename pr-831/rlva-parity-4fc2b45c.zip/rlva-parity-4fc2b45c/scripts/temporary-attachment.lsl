// Put controller.lsl in the same prim, with description T.
integer POINT = ATTACH_CHEST;
default
{
    state_entry() { llOwnerSay("[TEMP] Touch the rezzed object to request temporary attachment. Transfer permission is required."); }
    changed(integer change) { if (change & CHANGED_OWNER) llResetScript(); }
    touch_start(integer count)
    {
        if (llDetectedKey(0) != llGetOwner() || llGetAttached()) return;
        llRequestPermissions(llDetectedKey(0), PERMISSION_ATTACH);
    }
    run_time_permissions(integer granted)
    {
        if (granted & PERMISSION_ATTACH) llAttachToAvatarTemp(POINT);
        else llOwnerSay("[TEMP] Permissions=" + (string)granted);
    }
    attach(key avatar) { llOwnerSay("[TEMP] ATTACHED=" + (string)llGetAttached() + " source=" + (string)llGetKey()); }
}
