// RLVa parity test controller. Use separate prims with descriptions A, B, ... Z.
// No network service, debit permission, automatic wear or automatic teleport.
integer CONTROL = 210001;
integer lease = 180;
integer expires;
integer replay1;
integer replay2;
integer ownerListen;
integer replyListen;
integer sweepListen;
integer replyChannel;
integer sweepChannel;
integer sweepLine;
integer sweepWaiting;
integer sweepDeadline;
integer sweepNext;
string sweepCard;
string sweepId;
key cardRequest;
key owner;
string slot;
string boot;
list variables;

say(string text) { llOwnerSay("[RLVa " + slot + "] " + text); }

record(string tag, string message)
{
    say(tag + " chars=" + (string)llStringLength(message));
    integer length = llStringLength(message);
    if (!length) say(tag + " EMPTY=[]");
    integer position;
    for (position = 0; position < length; position += 160)
        say(tag + " DATA " + (string)(position / 160 + 1) + "=[" + llGetSubString(message, position, position + 159) + "]");
    // ASCII base64 fragments preserve the exact text despite chat display limits.
    string encoded = llStringToBase64(message);
    length = llStringLength(encoded);
    for (position = 0; position < length; position += 700)
        say(tag + " B64 " + (string)(position / 700 + 1) + "=" + llGetSubString(encoded, position, position + 699));
}

string replace(string text, string token, string value)
{
    return llDumpList2String(llParseStringKeepNulls(text, [token], []), value);
}

string slash(vector p)
{
    return (string)p.x + "/" + (string)p.y + "/" + (string)p.z;
}

string expand(string text, integer channel)
{
    text = replace(text, "{R}", (string)channel);
    text = replace(text, "{ME}", (string)owner);
    text = replace(text, "{SELF}", (string)llGetKey());
    text = replace(text, "{REGION}", llGetRegionName());
    list details = llGetObjectDetails(owner, [OBJECT_POS]);
    vector pos = llList2Vector(details, 0);
    text = replace(text, "{GLOBAL}", slash(llGetRegionCorner() + pos));
    text = replace(text, "{LOCAL}", slash(pos));
    integer i;
    for (i = 0; i < llGetListLength(variables); i += 2)
        text = replace(text, "{" + llList2String(variables, i) + "}", llList2String(variables, i + 1));
    return text;
}

integer send(string text, integer channel)
{
    text = expand(text, channel);
    string encoded = llStringToBase64(text);
    integer bytes = llStringLength(encoded) / 4 * 3;
    if (llGetSubString(encoded, -1, -1) == "=") --bytes;
    if (llGetSubString(encoded, -2, -2) == "=") --bytes;
    if (llGetSubString(text, 0, 0) != "@" || llSubStringIndex(text, "{") != -1 || llSubStringIndex(text, "}") != -1 || bytes > 900)
    {
        say("REFUSED: missing parameter, missing @ or command longer than 900 UTF-8 bytes.");
        return FALSE;
    }
    say("SEND " + text);
    llOwnerSay(text);
    if (lease > 0) expires = llGetUnixTime() + lease;
    return TRUE;
}

stopSweep()
{
    if (sweepListen) llListenRemove(sweepListen);
    sweepListen = 0;
    sweepWaiting = FALSE;
    sweepNext = 0;
    sweepCard = "";
    cardRequest = NULL_KEY;
}

panic()
{
    stopSweep();
    boot = "";
    replay1 = 0;
    replay2 = 0;
    expires = 0;
    llOwnerSay("@clear");
    say("CLEARED this prim only. Boot replay stopped. Other issuers may still restrict you.");
}

readNext()
{
    if (sweepLine >= 1000) { say("Sweep line limit reached."); stopSweep(); return; }
    sweepNext = 0;
    cardRequest = llGetNotecardLine(sweepCard, sweepLine);
}

startSweep(string card)
{
    stopSweep();
    if (llGetInventoryType(card) != INVENTORY_NOTECARD)
    {
        say("Missing notecard: " + card);
        return;
    }
    sweepCard = card;
    sweepLine = 0;
    say("READ-ONLY sweep started. REPLIED means transport only, not semantic PASS.");
    readNext();
}

configure()
{
    owner = llGetOwner();
    slot = llToUpper(llStringTrim(llGetObjectDesc(), STRING_TRIM));
    integer index = llSubStringIndex("ABCDEFGHIJKLMNOPQRSTUVWXYZ", slot);
    if (llStringLength(slot) != 1 || index == -1) { slot = "A"; index = 0; }
    replyChannel = 210011 + index;
    if (ownerListen) llListenRemove(ownerListen);
    if (replyListen) llListenRemove(replyListen);
    ownerListen = llListen(CONTROL, "", owner, "");
    replyListen = llListen(replyChannel, "", owner, "");
    // These are observation channels, never exceptions automatically added to RLVa.
    llListen(210101, "", owner, "");
    llListen(210102, "", owner, "");
    llListen(210103, "", owner, "");
    llSetTimerEvent(1.0);
    say("READY source=" + (string)llGetKey() + " link=" + (string)llGetLinkNumber()
        + " owner=" + (string)owner + " reply=" + (string)replyChannel
        + ". Control /210001 " + slot + "|@version={R} ; touch = clear; lease 180s.");
}

default
{
    state_entry() { configure(); panic(); }
    on_rez(integer parameter)
    {
        if (boot != "") { replay1 = llGetUnixTime() + 3; replay2 = llGetUnixTime() + 10; }
    }
    changed(integer change)
    {
        if (change & CHANGED_OWNER) llResetScript();
        if ((change & (CHANGED_REGION | CHANGED_TELEPORT)) && boot != "")
        { replay1 = llGetUnixTime() + 3; replay2 = llGetUnixTime() + 10; }
    }
    attach(key avatar)
    {
        if (avatar != NULL_KEY && boot != "")
        { replay1 = llGetUnixTime() + 3; replay2 = llGetUnixTime() + 10; }
        // Deliberately no automatic clear on detach: permits issuer-GC tests.
    }
    touch_start(integer count)
    {
        if (llDetectedKey(0) == owner) panic();
    }
    listen(integer channel, string name, key id, string message)
    {
        if (id != owner) return;
        if (channel == sweepChannel && sweepWaiting)
        {
            record("REPLIED " + sweepId + " channel=" + (string)channel, message);
            llListenRemove(sweepListen); sweepListen = 0; sweepWaiting = FALSE;
            ++sweepLine; sweepNext = llGetUnixTime() + 1;
            return;
        }
        if (channel != CONTROL)
        {
            record("RECEIVED channel=" + (string)channel, message);
            return;
        }
        integer separator = llSubStringIndex(message, "|");
        if (separator == -1) return;
        string target = llToUpper(llStringTrim(llGetSubString(message, 0, separator - 1), STRING_TRIM));
        if (target != slot && target != "ALL") return;
        string command = llStringTrim(llDeleteSubString(message, 0, separator), STRING_TRIM);
        if (command == "clear") { panic(); return; }
        if (command == "info") { say("SOURCE=" + (string)llGetKey() + " reply=" + (string)replyChannel + " lease=" + (string)lease); return; }
        if (llGetSubString(command, 0, 5) == "lease ")
        {
            integer value = (integer)llGetSubString(command, 6, -1);
            if (value < 0 || value > 3600) { say("Lease must be 0..3600 seconds."); return; }
            lease = value; expires = 0;
            if (lease > 0) expires = llGetUnixTime() + lease;
            say("Lease=" + (string)lease + "; 0 disables the test timeout."); return;
        }
        if (llGetSubString(command, 0, 3) == "set ")
        {
            string pair = llGetSubString(command, 4, -1);
            integer equal = llSubStringIndex(pair, "=");
            if (equal < 1) { say("Use set NAME=value"); return; }
            string variable = llToUpper(llStringTrim(llGetSubString(pair, 0, equal - 1), STRING_TRIM));
            string value = llGetSubString(pair, equal + 1, -1);
            if (llListFindList(["PEER","PEER2","OBJECT","SEAT","TEXTURE","GROUP","GROUPNAME","ROLE","ASSET","PRESET","DAYCYCLE","FOLDER","DESTINATION","BADREGION"], [variable]) == -1)
            { say("Unknown variable: " + variable); return; }
            integer position = llListFindList(variables, [variable]);
            if (position == -1) variables += [variable, value];
            else variables = llListReplaceList(variables, [variable, value], position, position + 1);
            say("Configured " + variable + " (runtime only)."); return;
        }
        if (llGetSubString(command, 0, 4) == "boot ")
        {
            boot = llGetSubString(command, 5, -1);
            if (boot == "off") { boot = ""; replay1 = 0; replay2 = 0; }
            else send(boot, replyChannel);
            say("Boot profile configured; use boot off to stop replay."); return;
        }
        if (llGetSubString(command, 0, 5) == "sweep ")
        { startSweep(llGetSubString(command, 6, -1)); return; }
        if (command == "stop") { stopSweep(); say("Sweep stopped."); return; }
        send(command, replyChannel);
    }
    dataserver(key request, string data)
    {
        if (request != cardRequest || sweepCard == "") return;
        if (data == EOF) { say("Sweep finished. Compare payloads with the reference; no overall PASS is inferred."); stopSweep(); return; }
        data = llStringTrim(data, STRING_TRIM);
        if (data == "" || llGetSubString(data, 0, 0) == "#") { ++sweepLine; readNext(); return; }
        integer separator = llSubStringIndex(data, "|");
        if (separator < 1) { say("Invalid card row " + (string)sweepLine); stopSweep(); return; }
        sweepId = llGetSubString(data, 0, separator - 1);
        string command = llGetSubString(data, separator + 1, -1);
        if (llGetSubString(command, -4, -1) != "={R}"
            || (llGetSubString(command, 0, 3) != "@get" && llGetSubString(command, 0, 7) != "@version" && llGetSubString(command, 0, 4) != "@find"))
        { say("REFUSED non-read-only card command: " + command); stopSweep(); return; }
        integer index = llSubStringIndex("ABCDEFGHIJKLMNOPQRSTUVWXYZ", slot);
        sweepChannel = 220000 + index * 5000 + sweepLine;
        if (sweepListen) llListenRemove(sweepListen);
        sweepListen = llListen(sweepChannel, "", owner, "");
        sweepWaiting = TRUE; sweepDeadline = llGetUnixTime() + 8;
        if (!send(command, sweepChannel)) stopSweep();
    }
    timer()
    {
        integer now = llGetUnixTime();
        if (expires && now >= expires) { panic(); say("LEASE EXPIRED: repeat any unfinished test; do not mark it PASS."); }
        if (replay1 && now >= replay1) { replay1 = 0; send(boot, replyChannel); }
        if (replay2 && now >= replay2) { replay2 = 0; send(boot, replyChannel); }
        if (sweepWaiting && now >= sweepDeadline)
        {
            say("TIMEOUT " + sweepId + ": transport/unsupported/server ambiguity; not a semantic PASS.");
            llListenRemove(sweepListen); sweepListen = 0; sweepWaiting = FALSE;
            ++sweepLine; sweepNext = now + 1;
        }
        if (sweepNext && now >= sweepNext) readNext();
    }
}
