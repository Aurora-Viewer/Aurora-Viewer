// Use on the consenting peer's account; copy+transfer payloads only.
key target;
string folder = "#RLV/~RLVa Validation/Gift";
default
{
    state_entry() { llListen(210004, "", llGetOwner(), ""); llOwnerSay("[GIFT] /210004 target UUID ; /210004 folder NAME ; then owner touch to offer."); }
    changed(integer change) { if (change & CHANGED_OWNER) llResetScript(); }
    listen(integer channel, string name, key id, string message)
    {
        if (llGetSubString(message, 0, 6) == "target ") target = (key)llGetSubString(message, 7, -1);
        else if (llGetSubString(message, 0, 6) == "folder ") folder = llGetSubString(message, 7, -1);
        llOwnerSay("[GIFT] Configured target=" + (string)target + " folder=" + folder);
    }
    touch_start(integer count)
    {
        if (llDetectedKey(0) != llGetOwner() || target == NULL_KEY) return;
        list payload;
        integer i;
        for (i = 0; i < llGetInventoryNumber(INVENTORY_ALL); ++i)
        {
            string item = llGetInventoryName(INVENTORY_ALL, i);
            integer permissions = llGetInventoryPermMask(item, MASK_OWNER);
            if (llGetInventoryType(item) != INVENTORY_SCRIPT && (permissions & PERM_COPY) && (permissions & PERM_TRANSFER)) payload += [item];
        }
        if (llGetListLength(payload) == 0) { llOwnerSay("[GIFT] Add a copy+transfer non-script payload first."); return; }
        llOwnerSay("[GIFT] OFFER count=" + (string)llGetListLength(payload));
        llGiveInventoryList(target, folder, payload);
    }
}
