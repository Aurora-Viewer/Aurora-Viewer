// Use as a rezzed touch/sit/edit/pay target, or wear another copy as a HUD.
default
{
    state_entry()
    {
        llSetText("RLVa target", <0.3, 1.0, 0.6>, 1.0);
        llSitTarget(<0.0, 0.0, 0.65>, ZERO_ROTATION);
        llSetPayPrice(PAY_HIDE, [1, PAY_HIDE, PAY_HIDE, PAY_HIDE]);
        llOwnerSay("[TARGET] UUID=" + (string)llGetKey() + " region-local=" + (string)llGetPos());
    }
    touch_start(integer count)
    {
        llOwnerSay("[TARGET] TOUCH avatar=" + (string)llDetectedKey(0) + " link=" + (string)llDetectedLinkNumber(0));
    }
    changed(integer change)
    {
        if (change & CHANGED_OWNER) llResetScript();
        if (change & CHANGED_LINK) llOwnerSay("[TARGET] SEATED=" + (string)llAvatarOnSitTarget());
    }
    money(key from, integer amount)
    {
        llOwnerSay("[TARGET] PAYMENT received=" + (string)amount + " from=" + (string)from);
    }
}
