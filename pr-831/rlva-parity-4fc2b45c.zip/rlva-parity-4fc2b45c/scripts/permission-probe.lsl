// The owner configures the mask and optional target on /210003.
// Touch requests permissions only; no animation/control/teleport/debit action runs.
integer channel = 210003;
integer mask = PERMISSION_TAKE_CONTROLS;
key target;
default
{
    state_entry() { target = llGetOwner(); llListen(channel, "", llGetOwner(), ""); llOwnerSay("[PERMISSIONS] Ready. /210003 controls|attach|animation|teleport|combined|release|target UUID"); }
    changed(integer change) { if (change & CHANGED_OWNER) llResetScript(); }
    listen(integer chan, string name, key id, string message)
    {
        if (message == "controls") mask = PERMISSION_TAKE_CONTROLS;
        else if (message == "attach") mask = PERMISSION_ATTACH;
        else if (message == "animation") mask = PERMISSION_TRIGGER_ANIMATION;
        else if (message == "teleport") mask = PERMISSION_TELEPORT;
        else if (message == "combined") mask = PERMISSION_ATTACH | PERMISSION_TELEPORT;
        else if (message == "release") { llRequestPermissions(target, 0); return; }
        else if (llGetSubString(message, 0, 6) == "target ") target = (key)llGetSubString(message, 7, -1);
        else { llOwnerSay("[PERMISSIONS] Unknown operation."); return; }
        llOwnerSay("[PERMISSIONS] Configured target=" + (string)target + " mask=" + (string)mask + "; touch to request.");
    }
    touch_start(integer count)
    {
        if (llDetectedKey(0) != target) return;
        llOwnerSay("[PERMISSIONS] REQUEST mask=" + (string)mask);
        llRequestPermissions(target, mask);
    }
    run_time_permissions(integer granted)
    {
        llOwnerSay("[PERMISSIONS] RESULT requested=" + (string)mask + " granted=" + (string)granted + " target=" + (string)llGetPermissionsKey());
    }
}
