"""Compare clean command-name catalogues; never infer behavioural parity."""
from pathlib import Path
import argparse
import json
import re


def read(path):
    raw=path.read_text(encoding='utf-8-sig').strip()
    names=[n for n in re.split(r'[\s;,|]+',raw) if n]
    if not names or any(not re.fullmatch(r'[a-z][a-z0-9_]*',n) for n in names):
        raise ValueError('Use command names only, one per line or separated by ; , |. No chat timestamps/prefixes: '+str(path))
    return set(names)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--legacy',required=True,type=Path)
    p.add_argument('--aurora',required=True,type=Path)
    a=p.parse_args()
    legacy,aurora=read(a.legacy),read(a.aurora)
    report=dict(legacy_count=len(legacy),aurora_count=len(aurora),
                missing_in_aurora=sorted(legacy-aurora),additional_in_aurora=sorted(aurora-legacy),
                scope='Catalogue names only; equal catalogues do not prove equal behaviour.')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    raise SystemExit(1 if legacy!=aurora else 0)
